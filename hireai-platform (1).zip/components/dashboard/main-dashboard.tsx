"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Users, Briefcase, Calendar, TrendingUp, Brain, FileText, Search, Plus, Clock, BarChart3 } from "lucide-react"
import { useState } from "react"
import Link from "next/link"

interface MainDashboardProps {
  user: any
  stats: {
    totalCandidates: number
    activeJobs: number
    recentSearches: any[]
    pendingInterviews: number
    newApplications: number
  }
}

export default function MainDashboard({ user, stats }: MainDashboardProps) {
  const [recentApplications] = useState([
    {
      id: 1,
      candidateName: "Sarah Chen",
      position: "Senior React Developer",
      appliedDate: "2 hours ago",
      status: "new",
      avatar: "/placeholder.svg?height=32&width=32",
    },
    {
      id: 2,
      candidateName: "Marcus Rodriguez",
      position: "AI/ML Engineer",
      appliedDate: "5 hours ago",
      status: "screening",
      avatar: "/placeholder.svg?height=32&width=32",
    },
    {
      id: 3,
      candidateName: "Priya Patel",
      position: "DevOps Engineer",
      appliedDate: "1 day ago",
      status: "interview",
      avatar: "/placeholder.svg?height=32&width=32",
    },
  ])

  const [upcomingInterviews] = useState([
    {
      id: 1,
      candidateName: "Alex Thompson",
      position: "Full Stack Developer",
      time: "Today, 2:00 PM",
      type: "Technical Interview",
      status: "confirmed",
    },
    {
      id: 2,
      candidateName: "Emily Davis",
      position: "Product Manager",
      time: "Tomorrow, 10:00 AM",
      type: "Behavioral Interview",
      status: "pending",
    },
    {
      id: 3,
      candidateName: "James Wilson",
      position: "Data Scientist",
      time: "Friday, 3:30 PM",
      type: "Final Interview",
      status: "confirmed",
    },
  ])

  const [pipelineData] = useState([
    { stage: "New Applications", count: 24, color: "bg-blue-500" },
    { stage: "Screening", count: 18, color: "bg-yellow-500" },
    { stage: "Technical Interview", count: 12, color: "bg-orange-500" },
    { stage: "Final Interview", count: 8, color: "bg-purple-500" },
    { stage: "Offer Extended", count: 3, color: "bg-green-500" },
  ])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "new":
        return "bg-blue-100 text-blue-800"
      case "screening":
        return "bg-yellow-100 text-yellow-800"
      case "interview":
        return "bg-purple-100 text-purple-800"
      case "confirmed":
        return "bg-green-100 text-green-800"
      case "pending":
        return "bg-orange-100 text-orange-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="flex-1 p-6 bg-gray-50">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">
            Welcome back, <span className="text-blue-600">{user?.full_name?.split(" ")[0] || "Recruiter"}</span>
          </h1>
          <p className="text-gray-600 mt-1">Here's your recruitment overview for today</p>
        </div>
        <div className="flex items-center gap-3">
          <Button asChild>
            <Link href="/dashboard/jobs/create">
              <Plus className="h-4 w-4 mr-2" />
              Create Job
            </Link>
          </Button>
          <Button variant="outline" asChild>
            <Link href="/dashboard/search">
              <Brain className="h-4 w-4 mr-2" />
              AI Search
            </Link>
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">New Applications</p>
                <p className="text-2xl font-bold text-gray-900">{stats.newApplications || 24}</p>
                <p className="text-xs text-green-600">+12% from last week</p>
              </div>
              <div className="h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Users className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Jobs</p>
                <p className="text-2xl font-bold text-gray-900">{stats.activeJobs || 8}</p>
                <p className="text-xs text-blue-600">3 closing soon</p>
              </div>
              <div className="h-12 w-12 bg-green-100 rounded-lg flex items-center justify-center">
                <Briefcase className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Interviews Today</p>
                <p className="text-2xl font-bold text-gray-900">{stats.pendingInterviews || 5}</p>
                <p className="text-xs text-orange-600">2 pending confirmation</p>
              </div>
              <div className="h-12 w-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <Calendar className="h-6 w-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Candidates</p>
                <p className="text-2xl font-bold text-gray-900">{stats.totalCandidates || 156}</p>
                <p className="text-xs text-green-600">+8% this month</p>
              </div>
              <div className="h-12 w-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="h-6 w-6 text-yellow-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* Recent Applications */}
        <Card className="lg:col-span-1">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg font-semibold flex items-center gap-2">
                <Users className="h-5 w-5 text-blue-600" />
                Recent Applications
              </CardTitle>
              <Button variant="ghost" size="sm" asChild>
                <Link href="/dashboard/candidates">View All</Link>
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {recentApplications.map((application) => (
              <div
                key={application.id}
                className="flex items-center gap-3 p-3 hover:bg-gray-50 rounded-lg transition-colors"
              >
                <Avatar className="h-10 w-10">
                  <AvatarImage src={application.avatar || "/placeholder.svg"} alt={application.candidateName} />
                  <AvatarFallback>
                    {application.candidateName
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-gray-900">{application.candidateName}</p>
                  <p className="text-sm text-gray-600">{application.position}</p>
                  <p className="text-xs text-gray-500">{application.appliedDate}</p>
                </div>
                <Badge className={getStatusColor(application.status)}>{application.status}</Badge>
              </div>
            ))}
            <Button variant="outline" className="w-full" asChild>
              <Link href="/dashboard/resume-parser">
                <FileText className="h-4 w-4 mr-2" />
                Parse New Resume
              </Link>
            </Button>
          </CardContent>
        </Card>

        {/* Screening Pipeline */}
        <Card className="lg:col-span-1">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg font-semibold flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-green-600" />
                Screening Pipeline
              </CardTitle>
              <Button variant="ghost" size="sm" asChild>
                <Link href="/dashboard/pipeline">View Pipeline</Link>
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {pipelineData.map((stage, index) => (
              <div key={index} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-700">{stage.stage}</span>
                  <span className="text-sm font-bold text-gray-900">{stage.count}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full ${stage.color}`}
                    style={{ width: `${(stage.count / 24) * 100}%` }}
                  />
                </div>
              </div>
            ))}
            <Button variant="outline" className="w-full" asChild>
              <Link href="/dashboard/analytics">
                <TrendingUp className="h-4 w-4 mr-2" />
                View Analytics
              </Link>
            </Button>
          </CardContent>
        </Card>

        {/* Scheduled Interviews */}
        <Card className="lg:col-span-1">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg font-semibold flex items-center gap-2">
                <Calendar className="h-5 w-5 text-purple-600" />
                Scheduled Interviews
              </CardTitle>
              <Button variant="ghost" size="sm" asChild>
                <Link href="/dashboard/interviews">View All</Link>
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {upcomingInterviews.map((interview) => (
              <div key={interview.id} className="p-3 border rounded-lg hover:bg-gray-50 transition-colors">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <p className="font-medium text-gray-900">{interview.candidateName}</p>
                    <p className="text-sm text-gray-600">{interview.position}</p>
                  </div>
                  <Badge className={getStatusColor(interview.status)}>{interview.status}</Badge>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Clock className="h-3 w-3" />
                  {interview.time}
                </div>
                <p className="text-xs text-gray-500 mt-1">{interview.type}</p>
              </div>
            ))}
            <Button variant="outline" className="w-full" asChild>
              <Link href="/dashboard/interviews/schedule">
                <Plus className="h-4 w-4 mr-2" />
                Schedule Interview
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold flex items-center gap-2">
            <Brain className="h-5 w-5 text-blue-600" />
            AI-Powered Tools
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Button variant="outline" className="h-20 flex-col gap-2" asChild>
              <Link href="/dashboard/search">
                <Search className="h-6 w-6" />
                <span>AI Unified Search</span>
              </Link>
            </Button>
            <Button variant="outline" className="h-20 flex-col gap-2" asChild>
              <Link href="/dashboard/resume-parser">
                <FileText className="h-6 w-6" />
                <span>Resume Parser</span>
              </Link>
            </Button>
            <Button variant="outline" className="h-20 flex-col gap-2" asChild>
              <Link href="/dashboard/candidates">
                <Users className="h-6 w-6" />
                <span>Candidate Database</span>
              </Link>
            </Button>
            <Button variant="outline" className="h-20 flex-col gap-2" asChild>
              <Link href="/dashboard/jobs/create">
                <Plus className="h-6 w-6" />
                <span>Create Job</span>
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
