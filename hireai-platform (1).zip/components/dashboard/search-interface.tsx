"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Search, Brain, MapPin, Clock, Star, AlertCircle, CheckCircle } from "lucide-react"
import { searchCandidates } from "@/app/actions/search"
import type { CandidateScore } from "@/lib/types"

export default function SearchInterface() {
  const [query, setQuery] = useState("")
  const [isSearching, setIsSearching] = useState(false)
  const [results, setResults] = useState<CandidateScore[]>([])
  const [searchTime, setSearchTime] = useState<number>(0)
  const [searchError, setSearchError] = useState<string | null>(null)
  const [isAiMode, setIsAiMode] = useState(true)

  const handleSearch = async () => {
    if (!query.trim()) return

    setIsSearching(true)
    setSearchError(null)
    const startTime = Date.now()

    try {
      const searchResults = await searchCandidates(query)
      setResults(searchResults)
      setSearchTime(Date.now() - startTime)

      // Check if we got demo results (indicates fallback mode)
      const isDemoMode = searchResults.some((result) => result.id.startsWith("demo-"))
      setIsAiMode(!isDemoMode)
    } catch (error) {
      console.error("Search failed:", error)
      setSearchError("Search failed. Please try again or contact support.")
      setResults([])
    } finally {
      setIsSearching(false)
    }
  }

  const exampleQueries = [
    "Find AI engineers with LangChain experience in Europe",
    "Senior React developers with 5+ years experience",
    "Python developers with machine learning skills in San Francisco",
    "Full-stack engineers open to remote work",
    "Data scientists with PhD in statistics",
  ]

  return (
    <div className="space-y-6">
      {/* AI Status Alert */}
      {!isAiMode && results.length > 0 && (
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Currently running in demo mode. Results are simulated for demonstration purposes.
          </AlertDescription>
        </Alert>
      )}

      {isAiMode && results.length > 0 && (
        <Alert className="border-green-200 bg-green-50">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-800">
            AI-powered search is active. Results are analyzed using advanced machine learning.
          </AlertDescription>
        </Alert>
      )}

      {/* Search Interface */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5 text-blue-600" />
            AI-Powered Candidate Search
          </CardTitle>
          <CardDescription>
            Type your search in plain English. Our AI will understand and find the best matching candidates.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              placeholder="e.g., Find AI engineers with LangChain experience in Europe"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && handleSearch()}
              className="flex-1"
            />
            <Button onClick={handleSearch} disabled={isSearching}>
              {isSearching ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
              Search
            </Button>
          </div>

          {/* Error Display */}
          {searchError && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{searchError}</AlertDescription>
            </Alert>
          )}

          {/* Example Queries */}
          <div className="space-y-2">
            <p className="text-sm text-gray-600">Try these example searches:</p>
            <div className="flex flex-wrap gap-2">
              {exampleQueries.map((example, index) => (
                <Badge
                  key={index}
                  variant="outline"
                  className="cursor-pointer hover:bg-gray-100"
                  onClick={() => setQuery(example)}
                >
                  {example}
                </Badge>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Search Results */}
      {results.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Search Results</span>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Clock className="h-4 w-4" />
                {searchTime}ms
              </div>
            </CardTitle>
            <CardDescription>
              Found {results.length} candidates matching your criteria
              {!isAiMode && " (Demo Mode)"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {results.map((result) => (
                <div key={result.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-semibold text-lg">{result.candidate?.full_name}</h3>
                        <div className="flex items-center gap-1">
                          <Star className="h-4 w-4 text-yellow-500 fill-current" />
                          <span className="font-medium">{result.overall_score.toFixed(1)}</span>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <span>{result.candidate?.current_position}</span>
                          {result.candidate?.current_company && (
                            <>
                              <span>at</span>
                              <span className="font-medium">{result.candidate.current_company}</span>
                            </>
                          )}
                        </div>

                        {result.candidate?.location && (
                          <div className="flex items-center gap-1 text-sm text-gray-600">
                            <MapPin className="h-3 w-3" />
                            {result.candidate.location}
                          </div>
                        )}

                        <div className="flex flex-wrap gap-1">
                          {result.candidate?.skills.slice(0, 5).map((skill, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {skill}
                            </Badge>
                          ))}
                          {result.candidate?.skills.length > 5 && (
                            <Badge variant="outline" className="text-xs">
                              +{result.candidate.skills.length - 5} more
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="text-right space-y-1">
                      <div className="text-sm">
                        <div>Skills: {result.skill_match_score.toFixed(1)}</div>
                        <div>Experience: {result.experience_score.toFixed(1)}</div>
                        <div>Location: {result.location_score.toFixed(1)}</div>
                      </div>
                      <Button size="sm" variant="outline">
                        View Profile
                      </Button>
                    </div>
                  </div>

                  {result.ai_reasoning && (
                    <div className="mt-3 p-3 bg-blue-50 rounded-md">
                      <p className="text-sm text-blue-800">
                        <strong>AI Analysis:</strong> {result.ai_reasoning}
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* No Results */}
      {!isSearching && results.length === 0 && query && !searchError && (
        <Card>
          <CardContent className="text-center py-12">
            <Search className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No candidates found</h3>
            <p className="text-gray-600">Try adjusting your search criteria or using different keywords.</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
