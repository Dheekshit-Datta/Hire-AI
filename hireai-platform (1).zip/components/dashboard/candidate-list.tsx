"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import {
  Users,
  MapPin,
  Briefcase,
  Mail,
  Phone,
  Eye,
  MessageCircle,
  Calendar,
  AlertCircle,
  GraduationCap,
  Award,
} from "lucide-react"
import { getCandidates } from "@/app/actions/candidates"

export default function CandidateList() {
  const [candidates, setCandidates] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [filterLocation, setFilterLocation] = useState("")
  const [filterSkill, setFilterSkill] = useState("")
  const [selectedCandidate, setSelectedCandidate] = useState<any>(null)
  const [showProfile, setShowProfile] = useState(false)
  const [isDemo, setIsDemo] = useState(false)

  useEffect(() => {
    loadCandidates()
  }, [])

  const loadCandidates = async () => {
    try {
      setLoading(true)
      const data = await getCandidates()
      setCandidates(data)

      // Check if we're in demo mode (no real database connection)
      const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
      setIsDemo(!supabaseUrl)
    } catch (error) {
      console.error("Error loading candidates:", error)
      // This shouldn't happen now since getCandidates always returns data
      setCandidates([])
    } finally {
      setLoading(false)
    }
  }

  const filteredCandidates = candidates.filter((candidate) => {
    const matchesSearch =
      candidate.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      candidate.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      candidate.current_position?.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesLocation = !filterLocation || candidate.location?.toLowerCase().includes(filterLocation.toLowerCase())

    const matchesSkill =
      !filterSkill || candidate.skills?.some((skill: string) => skill.toLowerCase().includes(filterSkill.toLowerCase()))

    return matchesSearch && matchesLocation && matchesSkill
  })

  const handleViewProfile = (candidate: any) => {
    setSelectedCandidate(candidate)
    setShowProfile(true)
  }

  const handleContact = (candidate: any) => {
    // Create mailto link
    const subject = encodeURIComponent(`Opportunity at Your Company`)
    const body = encodeURIComponent(`Hi ${candidate.full_name},

I came across your profile and I'm impressed with your background in ${candidate.current_position}. 

I'd love to discuss an exciting opportunity that might be a great fit for your skills.

Best regards,
[Your Name]`)

    window.open(`mailto:${candidate.email}?subject=${subject}&body=${body}`)
  }

  const formatEducation = (education: any) => {
    if (!education) return "Not specified"

    if (typeof education === "string") return education

    if (Array.isArray(education)) {
      return education
        .map((edu: any) => {
          if (typeof edu === "string") return edu
          return `${edu.degree} in ${edu.field || "General Studies"} from ${edu.school} (${edu.year})`
        })
        .join(", ")
    }

    if (typeof education === "object") {
      return `${education.degree} in ${education.field || "General Studies"} from ${education.school} (${education.year})`
    }

    return "Not specified"
  }

  const formatCertifications = (certifications: any) => {
    if (!certifications || !Array.isArray(certifications) || certifications.length === 0) {
      return "None listed"
    }

    return certifications
      .map((cert: any) => {
        if (typeof cert === "string") return cert
        return `${cert.name} (${cert.issuer}, ${cert.year})`
      })
      .join(", ")
  }

  if (loading) {
    return (
      <Card>
        <CardContent className="text-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading candidates...</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Demo Mode Banner */}
      {isDemo && (
        <Card className="border-orange-200 bg-orange-50">
          <CardContent className="flex items-center gap-3 py-4">
            <AlertCircle className="h-5 w-5 text-orange-600" />
            <div>
              <p className="text-sm font-medium text-orange-800">Demo Mode</p>
              <p className="text-sm text-orange-700">
                You're viewing sample candidate data. Connect your database to see real candidates.
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Candidate Database
          </CardTitle>
          <CardDescription>Browse and filter through all candidates in your database</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4">
            <Input
              placeholder="Search by name, email, or position..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1"
            />
            <Input
              placeholder="Filter by location..."
              value={filterLocation}
              onChange={(e) => setFilterLocation(e.target.value)}
              className="sm:w-48"
            />
            <Input
              placeholder="Filter by skill..."
              value={filterSkill}
              onChange={(e) => setFilterSkill(e.target.value)}
              className="sm:w-48"
            />
          </div>
        </CardContent>
      </Card>

      {/* Candidates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCandidates.map((candidate) => (
          <Card key={candidate.id} className="hover:shadow-md transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-lg">{candidate.full_name}</CardTitle>
                  <CardDescription>{candidate.current_position}</CardDescription>
                </div>
                <Badge variant={candidate.availability_status === "available" ? "default" : "secondary"}>
                  {candidate.availability_status}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                {candidate.current_company && (
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Briefcase className="h-3 w-3" />
                    {candidate.current_company}
                  </div>
                )}

                {candidate.location && (
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <MapPin className="h-3 w-3" />
                    {candidate.location}
                  </div>
                )}

                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Mail className="h-3 w-3" />
                  {candidate.email}
                </div>

                {candidate.phone && (
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Phone className="h-3 w-3" />
                    {candidate.phone}
                  </div>
                )}
              </div>

              <div>
                <p className="text-sm font-medium mb-2">Skills</p>
                <div className="flex flex-wrap gap-1">
                  {candidate.skills?.slice(0, 4).map((skill: string, index: number) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {skill}
                    </Badge>
                  ))}
                  {candidate.skills?.length > 4 && (
                    <Badge variant="outline" className="text-xs">
                      +{candidate.skills.length - 4}
                    </Badge>
                  )}
                </div>
              </div>

              <div className="flex gap-2">
                <Button size="sm" className="flex-1" onClick={() => handleViewProfile(candidate)}>
                  <Eye className="h-3 w-3 mr-1" />
                  View Profile
                </Button>
                <Button size="sm" variant="outline" onClick={() => handleContact(candidate)}>
                  <MessageCircle className="h-3 w-3 mr-1" />
                  Contact
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredCandidates.length === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No candidates found</h3>
            <p className="text-gray-600">
              {candidates.length === 0
                ? "No candidates in your database yet. Add some candidates to get started."
                : "No candidates match your current filters. Try adjusting your search criteria."}
            </p>
          </CardContent>
        </Card>
      )}

      {/* Profile Dialog */}
      <Dialog open={showProfile} onOpenChange={setShowProfile}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{selectedCandidate?.full_name}</DialogTitle>
            <DialogDescription>{selectedCandidate?.current_position}</DialogDescription>
          </DialogHeader>
          {selectedCandidate && (
            <div className="space-y-6">
              {/* Contact Info */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold mb-2">Contact Information</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4" />
                      <a href={`mailto:${selectedCandidate.email}`} className="text-blue-600 hover:underline">
                        {selectedCandidate.email}
                      </a>
                    </div>
                    {selectedCandidate.phone && (
                      <div className="flex items-center gap-2">
                        <Phone className="h-4 w-4" />
                        <a href={`tel:${selectedCandidate.phone}`} className="text-blue-600 hover:underline">
                          {selectedCandidate.phone}
                        </a>
                      </div>
                    )}
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4" />
                      <span>{selectedCandidate.location}</span>
                    </div>
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Professional Info</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <Briefcase className="h-4 w-4" />
                      <span>{selectedCandidate.current_company}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      <span>{selectedCandidate.experience_years} years experience</span>
                    </div>
                    <Badge variant={selectedCandidate.availability_status === "available" ? "default" : "secondary"}>
                      {selectedCandidate.availability_status}
                    </Badge>
                  </div>
                </div>
              </div>

              {/* Education */}
              <div>
                <h4 className="font-semibold mb-2 flex items-center gap-2">
                  <GraduationCap className="h-4 w-4" />
                  Education
                </h4>
                <div className="text-sm text-gray-600">
                  {Array.isArray(selectedCandidate.education) ? (
                    <div className="space-y-2">
                      {selectedCandidate.education.map((edu: any, index: number) => (
                        <div key={index} className="border-l-2 border-gray-200 pl-3">
                          <p className="font-medium">
                            {edu.degree} in {edu.field}
                          </p>
                          <p className="text-gray-500">
                            {edu.school} • {edu.year}
                          </p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p>{formatEducation(selectedCandidate.education)}</p>
                  )}
                </div>
              </div>

              {/* Certifications */}
              {selectedCandidate.certifications && selectedCandidate.certifications.length > 0 && (
                <div>
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Award className="h-4 w-4" />
                    Certifications
                  </h4>
                  <div className="space-y-2">
                    {selectedCandidate.certifications.map((cert: any, index: number) => (
                      <div key={index} className="text-sm text-gray-600 border-l-2 border-gray-200 pl-3">
                        <p className="font-medium">{cert.name}</p>
                        <p className="text-gray-500">
                          {cert.issuer} • {cert.year}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Skills */}
              <div>
                <h4 className="font-semibold mb-2">Skills</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedCandidate.skills?.map((skill: string, index: number) => (
                    <Badge key={index} variant="outline">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Languages */}
              {selectedCandidate.languages && selectedCandidate.languages.length > 0 && (
                <div>
                  <h4 className="font-semibold mb-2">Languages</h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedCandidate.languages.map((language: string, index: number) => (
                      <Badge key={index} variant="secondary">
                        {language}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* Salary Expectation */}
              {selectedCandidate.salary_expectation && (
                <div>
                  <h4 className="font-semibold mb-2">Salary Expectation</h4>
                  <p className="text-sm text-gray-600">
                    ${selectedCandidate.salary_expectation.toLocaleString()} per year
                  </p>
                </div>
              )}

              {/* Actions */}
              <div className="flex gap-2">
                <Button onClick={() => handleContact(selectedCandidate)} className="flex-1">
                  <MessageCircle className="h-4 w-4 mr-2" />
                  Send Message
                </Button>
                <Button variant="outline">
                  <Calendar className="h-4 w-4 mr-2" />
                  Schedule Interview
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
