"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Upload, FileText, Loader2, CheckCircle } from "lucide-react"
import { parseAndAddCandidate } from "@/app/actions/resume-parsing"

export default function ResumeUpload() {
  const [file, setFile] = useState<File | null>(null)
  const [resumeText, setResumeText] = useState("")
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [error, setError] = useState("")

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0]
    if (selectedFile) {
      setFile(selectedFile)

      // Read file content
      const reader = new FileReader()
      reader.onload = (event) => {
        const text = event.target?.result as string
        setResumeText(text)
      }
      reader.readAsText(selectedFile)
    }
  }

  const handleParseResume = async () => {
    if (!resumeText.trim()) {
      setError("Please upload a resume or enter resume text")
      return
    }

    setLoading(true)
    setError("")

    try {
      const parsedCandidate = await parseAndAddCandidate(resumeText)
      setResult(parsedCandidate)
    } catch (err) {
      setError("Failed to parse resume. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  if (result) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-green-600" />
            Resume Parsed Successfully
          </CardTitle>
          <CardDescription>Candidate has been added to your database</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="font-medium">Name</Label>
              <p>{result.full_name}</p>
            </div>
            <div>
              <Label className="font-medium">Email</Label>
              <p>{result.email}</p>
            </div>
            <div>
              <Label className="font-medium">Experience</Label>
              <p>{result.experience_years} years</p>
            </div>
            <div>
              <Label className="font-medium">Current Position</Label>
              <p>{result.current_position}</p>
            </div>
          </div>

          <div>
            <Label className="font-medium">Skills Extracted</Label>
            <div className="flex flex-wrap gap-1 mt-1">
              {result.skills.slice(0, 10).map((skill: string, index: number) => (
                <span key={index} className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs">
                  {skill}
                </span>
              ))}
              {result.skills.length > 10 && (
                <span className="px-2 py-1 bg-gray-100 text-gray-600 rounded text-xs">
                  +{result.skills.length - 10} more
                </span>
              )}
            </div>
          </div>

          <Button onClick={() => setResult(null)} className="w-full">
            Parse Another Resume
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Upload className="h-5 w-5" />
          AI Resume Parser
        </CardTitle>
        <CardDescription>
          Upload a resume or paste resume text. Our AI will automatically extract skills, experience, and other details.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="space-y-2">
          <Label htmlFor="resume-file">Upload Resume File</Label>
          <Input id="resume-file" type="file" accept=".txt,.pdf,.doc,.docx" onChange={handleFileUpload} />
          <p className="text-xs text-gray-600">Supported formats: TXT, PDF, DOC, DOCX</p>
        </div>

        <div className="text-center text-gray-500">or</div>

        <div className="space-y-2">
          <Label htmlFor="resume-text">Paste Resume Text</Label>
          <textarea
            id="resume-text"
            className="w-full h-40 p-3 border rounded-md resize-none"
            placeholder="Paste the resume content here..."
            value={resumeText}
            onChange={(e) => setResumeText(e.target.value)}
          />
        </div>

        <Button onClick={handleParseResume} disabled={loading || !resumeText.trim()} className="w-full">
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Parsing Resume with AI...
            </>
          ) : (
            <>
              <FileText className="mr-2 h-4 w-4" />
              Parse Resume
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  )
}
