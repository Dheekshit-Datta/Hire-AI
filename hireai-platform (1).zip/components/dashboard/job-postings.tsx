"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Briefcase,
  MapPin,
  DollarSign,
  Clock,
  Plus,
  Users,
  Edit,
  Eye,
  Search,
  Mail,
  Calendar,
  Star,
} from "lucide-react"

const mockJobs = [
  {
    id: "1",
    title: "Senior React Developer",
    description:
      "We are looking for an experienced React developer to join our team and build amazing user interfaces...",
    location: "San Francisco, CA",
    salary_range_min: 120000,
    salary_range_max: 160000,
    experience_required: 5,
    skills_required: ["React", "TypeScript", "Node.js", "GraphQL"],
    status: "active",
    applicants: 23,
    created_at: "2024-01-15",
  },
  {
    id: "2",
    title: "AI/ML Engineer",
    description:
      "Join our AI team to build cutting-edge machine learning solutions that will transform our industry...",
    location: "Remote",
    salary_range_min: 140000,
    salary_range_max: 180000,
    experience_required: 3,
    skills_required: ["Python", "TensorFlow", "PyTorch", "AWS"],
    status: "active",
    applicants: 45,
    created_at: "2024-01-10",
  },
  {
    id: "3",
    title: "DevOps Engineer",
    description: "Help us scale our infrastructure and improve deployment processes with modern DevOps practices...",
    location: "New York, NY",
    salary_range_min: 110000,
    salary_range_max: 140000,
    experience_required: 4,
    skills_required: ["AWS", "Kubernetes", "Docker", "Terraform"],
    status: "paused",
    applicants: 18,
    created_at: "2024-01-08",
  },
]

const mockApplicants = [
  {
    id: "1",
    name: "Sarah Chen",
    email: "sarah.chen@email.com",
    position: "Senior React Developer",
    experience: 6,
    skills: ["React", "TypeScript", "Node.js", "GraphQL", "AWS"],
    status: "new",
    appliedDate: "2024-01-20",
    score: 92,
    avatar: "https://randomuser.me/api/portraits/women/32.jpg",
    location: "San Francisco, CA",
    currentCompany: "TechCorp",
    summary:
      "Experienced React developer with 6+ years building scalable web applications. Expert in modern JavaScript frameworks and cloud technologies.",
  },
  {
    id: "2",
    name: "Marcus Johnson",
    email: "marcus.j@email.com",
    position: "Senior React Developer",
    experience: 5,
    skills: ["React", "JavaScript", "Node.js", "MongoDB"],
    status: "screening",
    appliedDate: "2024-01-19",
    score: 87,
    avatar: "https://randomuser.me/api/portraits/men/45.jpg",
    location: "Austin, TX",
    currentCompany: "StartupXYZ",
    summary: "Full-stack developer passionate about creating user-friendly interfaces and scalable backend systems.",
  },
  {
    id: "3",
    name: "Elena Rodriguez",
    email: "elena.r@email.com",
    position: "Senior React Developer",
    experience: 7,
    skills: ["React", "TypeScript", "Next.js", "PostgreSQL"],
    status: "interview",
    appliedDate: "2024-01-18",
    score: 94,
    avatar: "https://randomuser.me/api/portraits/women/65.jpg",
    location: "Remote",
    currentCompany: "DataTech Europe",
    summary:
      "Senior developer with expertise in React ecosystem and modern web technologies. Strong background in TypeScript and database design.",
  },
]

export default function JobPostings() {
  const router = useRouter()
  const [jobs] = useState(mockJobs)
  const [selectedJob, setSelectedJob] = useState<any>(null)
  const [showApplicants, setShowApplicants] = useState(false)
  const [selectedApplicant, setSelectedApplicant] = useState<any>(null)
  const [showProfile, setShowProfile] = useState(false)

  const handleViewApplications = (job: any) => {
    setSelectedJob(job)
    setShowApplicants(true)
  }

  const handleAISearchCandidates = (job: any) => {
    const searchQuery = `${job.title} with ${job.skills_required.join(", ")} skills in ${job.location}`
    router.push(`/dashboard/search?q=${encodeURIComponent(searchQuery)}`)
  }

  const handleEditJob = (job: any) => {
    // For now, show an alert. In a real app, this would navigate to edit page
    alert(`Edit job functionality would navigate to /dashboard/jobs/edit/${job.id}`)
  }

  const handleViewProfile = (applicant: any) => {
    setSelectedApplicant(applicant)
    setShowProfile(true)
  }

  const handleContactApplicant = (applicant: any) => {
    const subject = `Regarding your application for ${selectedJob?.title}`
    const body = `Hi ${applicant.name},\n\nThank you for your interest in the ${selectedJob?.title} position at our company. We'd like to discuss your application further.\n\nBest regards,\nHiring Team`
    window.open(`mailto:${applicant.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "new":
        return "bg-blue-100 text-blue-800"
      case "screening":
        return "bg-yellow-100 text-yellow-800"
      case "interview":
        return "bg-purple-100 text-purple-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Briefcase className="h-5 w-5" />
                Job Postings
              </CardTitle>
              <CardDescription>Manage your active job postings and track applications</CardDescription>
            </div>
            <Button onClick={() => router.push("/dashboard/jobs/create")}>
              <Plus className="h-4 w-4 mr-2" />
              Create Job
            </Button>
          </div>
        </CardHeader>
      </Card>

      {/* Job Cards */}
      <div className="space-y-4">
        {jobs.map((job) => (
          <Card key={job.id}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-xl">{job.title}</CardTitle>
                  <CardDescription className="mt-2">{job.description}</CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={job.status === "active" ? "default" : "secondary"}>{job.status}</Badge>
                  <div className="text-right">
                    <div className="flex items-center gap-1 text-sm font-medium">
                      <Users className="h-3 w-3" />
                      {job.applicants}
                    </div>
                    <div className="text-xs text-gray-600">applicants</div>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-gray-500" />
                  <span>{job.location}</span>
                </div>
                <div className="flex items-center gap-2">
                  <DollarSign className="h-4 w-4 text-gray-500" />
                  <span>
                    ${job.salary_range_min.toLocaleString()} - ${job.salary_range_max.toLocaleString()}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-gray-500" />
                  <span>{job.experience_required}+ years experience</span>
                </div>
              </div>

              <div>
                <p className="text-sm font-medium mb-2">Required Skills</p>
                <div className="flex flex-wrap gap-2">
                  {job.skills_required.map((skill, index) => (
                    <Badge key={index} variant="outline">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="flex gap-2">
                <Button size="sm" onClick={() => handleViewApplications(job)}>
                  <Eye className="h-4 w-4 mr-1" />
                  View Applications
                </Button>
                <Button size="sm" variant="outline" onClick={() => handleAISearchCandidates(job)}>
                  <Search className="h-4 w-4 mr-1" />
                  AI Search Candidates
                </Button>
                <Button size="sm" variant="outline" onClick={() => handleEditJob(job)}>
                  <Edit className="h-4 w-4 mr-1" />
                  Edit Job
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {jobs.length === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <Briefcase className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No job postings yet</h3>
            <p className="text-gray-600 mb-4">Create your first job posting to start finding candidates with AI.</p>
            <Button onClick={() => router.push("/dashboard/jobs/create")}>
              <Plus className="h-4 w-4 mr-2" />
              Create Your First Job
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Applicants Dialog */}
      <Dialog open={showApplicants} onOpenChange={setShowApplicants}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Applications for {selectedJob?.title}</DialogTitle>
            <DialogDescription>Review and manage candidate applications</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {mockApplicants.map((applicant) => (
              <Card key={applicant.id}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4 flex-1">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={applicant.avatar || "/placeholder.svg"} alt={applicant.name} />
                        <AvatarFallback>{applicant.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h4 className="font-semibold">{applicant.name}</h4>
                          <Badge className={getStatusColor(applicant.status)}>{applicant.status}</Badge>
                          <div className="flex items-center gap-1">
                            <Star className="h-4 w-4 text-yellow-500 fill-current" />
                            <span className="text-sm font-medium">{applicant.score}%</span>
                          </div>
                        </div>
                        <p className="text-sm text-gray-600 mb-1">{applicant.email}</p>
                        <p className="text-sm text-gray-600 mb-1">
                          {applicant.experience} years experience • {applicant.location}
                        </p>
                        <p className="text-sm text-gray-600 mb-2">Currently at {applicant.currentCompany}</p>
                        <div className="flex flex-wrap gap-1">
                          {applicant.skills.map((skill, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {skill}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" onClick={() => handleViewProfile(applicant)}>
                        <Eye className="h-4 w-4 mr-1" />
                        View Profile
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => handleContactApplicant(applicant)}>
                        <Mail className="h-4 w-4 mr-1" />
                        Contact
                      </Button>
                      <Button size="sm" variant="outline">
                        <Calendar className="h-4 w-4 mr-1" />
                        Schedule
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* Profile Dialog */}
      <Dialog open={showProfile} onOpenChange={setShowProfile}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Candidate Profile</DialogTitle>
            <DialogDescription>Detailed information about {selectedApplicant?.name}</DialogDescription>
          </DialogHeader>
          {selectedApplicant && (
            <div className="space-y-6">
              {/* Header */}
              <div className="flex items-start gap-4">
                <Avatar className="h-16 w-16">
                  <AvatarImage src={selectedApplicant.avatar || "/placeholder.svg"} alt={selectedApplicant.name} />
                  <AvatarFallback className="text-lg">{selectedApplicant.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold">{selectedApplicant.name}</h3>
                  <p className="text-gray-600">{selectedApplicant.position}</p>
                  <p className="text-sm text-gray-500">{selectedApplicant.location}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 text-yellow-500 fill-current" />
                      <span className="font-medium">{selectedApplicant.score}% Match</span>
                    </div>
                    <Badge className={getStatusColor(selectedApplicant.status)}>{selectedApplicant.status}</Badge>
                  </div>
                </div>
              </div>

              {/* Contact Info */}
              <div>
                <h4 className="font-semibold mb-2">Contact Information</h4>
                <div className="space-y-1 text-sm">
                  <p>
                    <strong>Email:</strong> {selectedApplicant.email}
                  </p>
                  <p>
                    <strong>Current Company:</strong> {selectedApplicant.currentCompany}
                  </p>
                  <p>
                    <strong>Experience:</strong> {selectedApplicant.experience} years
                  </p>
                  <p>
                    <strong>Applied:</strong> {selectedApplicant.appliedDate}
                  </p>
                </div>
              </div>

              {/* Summary */}
              <div>
                <h4 className="font-semibold mb-2">Summary</h4>
                <p className="text-sm text-gray-700">{selectedApplicant.summary}</p>
              </div>

              {/* Skills */}
              <div>
                <h4 className="font-semibold mb-2">Skills</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedApplicant.skills.map((skill: string, index: number) => (
                    <Badge key={index} variant="secondary">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-2 pt-4 border-t">
                <Button onClick={() => handleContactApplicant(selectedApplicant)}>
                  <Mail className="h-4 w-4 mr-2" />
                  Send Email
                </Button>
                <Button variant="outline">
                  <Calendar className="h-4 w-4 mr-2" />
                  Schedule Interview
                </Button>
                <Button variant="outline">Download Resume</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
