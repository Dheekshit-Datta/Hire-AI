"use client"

import { useState } from "react"
import SidebarNavigation from "./sidebar-navigation"
import MainDashboard from "./main-dashboard"
import EnhancedSearchInterface from "./enhanced-search-interface"
import CandidateList from "./candidate-list"
import AnalyticsDashboard from "./analytics-dashboard"
import JobPostings from "./job-postings"
import DemoInterviewSystem from "./demo-interview-system"
import ModernLinkedInSearch from "./modern-linkedin-search"

interface ModernDashboardLayoutProps {
  user: any
  stats: {
    totalCandidates: number
    activeJobs: number
    recentSearches: any[]
    pendingInterviews?: number
    newApplications?: number
  }
}

export default function ModernDashboardLayout({ user, stats }: ModernDashboardLayoutProps) {
  const [activeTab, setActiveTab] = useState("dashboard")

  // Enhanced stats with default values
  const enhancedStats = {
    ...stats,
    pendingInterviews: stats.pendingInterviews || 3,
    newApplications: stats.newApplications || 12,
  }

  const renderContent = () => {
    switch (activeTab) {
      case "dashboard":
        return <MainDashboard user={user} stats={enhancedStats} />
      case "search":
        return (
          <div className="flex-1 p-6 bg-gray-50">
            <EnhancedSearchInterface />
          </div>
        )
      case "candidates":
        return (
          <div className="flex-1 p-6 bg-gray-50">
            <CandidateList />
          </div>
        )
      case "linkedin":
        return (
          <div className="flex-1 p-6 bg-gray-50">
            <ModernLinkedInSearch />
          </div>
        )
      case "jobs":
        return (
          <div className="flex-1 p-6 bg-gray-50">
            <JobPostings />
          </div>
        )
      case "interviews":
        return (
          <div className="flex-1 p-6 bg-gray-50">
            <DemoInterviewSystem />
          </div>
        )
      case "analytics":
        return (
          <div className="flex-1 p-6 bg-gray-50">
            <AnalyticsDashboard />
          </div>
        )
      default:
        return <MainDashboard user={user} stats={enhancedStats} />
    }
  }

  return (
    <div className="flex h-screen bg-gray-50">
      <SidebarNavigation user={user} stats={enhancedStats} onTabChange={setActiveTab} activeTab={activeTab} />
      {renderContent()}
    </div>
  )
}
