"use client"

import ModernDashboardLayout from "./modern-dashboard-layout"

interface DashboardContentProps {
  user: any
  stats: {
    totalCandidates: number
    activeJobs: number
    recentSearches: any[]
  }
}

export default function DashboardContent({ user, stats }: DashboardContentProps) {
  return <ModernDashboardLayout user={user} stats={stats} />
}
