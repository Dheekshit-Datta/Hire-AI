"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Search, MapPin, Briefcase, Linkedin, ExternalLink, UserPlus } from "lucide-react"
import { searchLinkedInProfiles, type LinkedInProfile } from "@/lib/services/linkedin-scraper"
import { addLinkedInCandidateToDatabase } from "@/app/actions/enhanced-search"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"

export default function LinkedInSearch() {
  const [query, setQuery] = useState("")
  const [isSearching, setIsSearching] = useState(false)
  const [profiles, setProfiles] = useState<LinkedInProfile[]>([])
  const [addingCandidates, setAddingCandidates] = useState<Set<string>>(new Set())
  const [searchTime, setSearchTime] = useState<number>(0)
  const [searchStatus, setSearchStatus] = useState<string>("")

  const handleSearch = async () => {
    if (!query.trim()) return

    setIsSearching(true)
    setSearchStatus("Connecting to LinkedIn API...")
    setProfiles([])

    const startTime = Date.now()

    try {
      // Parse the query to extract skills, location, etc.
      const skills = extractSkillsFromQuery(query)
      const location = extractLocationFromQuery(query)
      const experience = extractExperienceFromQuery(query)
      const jobTitle = extractJobTitleFromQuery(query)

      setSearchStatus("Searching LinkedIn profiles...")

      // Simulate API progress
      await new Promise((resolve) => setTimeout(resolve, 800))
      setSearchStatus("Analyzing profiles...")

      await new Promise((resolve) => setTimeout(resolve, 700))
      setSearchStatus("Filtering results...")

      // Search LinkedIn profiles
      const results = await searchLinkedInProfiles({
        query,
        skills,
        location,
        experience,
        jobTitle,
      })

      setProfiles(results)
      setSearchTime(Date.now() - startTime)
    } catch (error) {
      console.error("LinkedIn search failed:", error)
    } finally {
      setIsSearching(false)
      setSearchStatus("")
    }
  }

  const handleAddToDatabase = async (profile: LinkedInProfile) => {
    const profileId = profile.name.replace(/\s+/g, "-").toLowerCase()
    setAddingCandidates((prev) => new Set(prev).add(profileId))

    try {
      const candidateData = convertLinkedInProfileToCandidate(profile)
      await addLinkedInCandidateToDatabase(candidateData)

      // Show success message or update UI
      // For now, we'll just remove the profile from the list
      setProfiles((prev) => prev.filter((p) => p.name !== profile.name))
    } catch (error) {
      console.error("Failed to add candidate:", error)
    } finally {
      setAddingCandidates((prev) => {
        const newSet = new Set(prev)
        newSet.delete(profileId)
        return newSet
      })
    }
  }

  // Helper functions to extract information from the query
  const extractSkillsFromQuery = (query: string): string[] => {
    const commonSkills = [
      "javascript",
      "python",
      "react",
      "node",
      "typescript",
      "java",
      "c++",
      "sql",
      "aws",
      "docker",
      "kubernetes",
      "git",
      "mongodb",
      "postgresql",
      "redis",
      "machine learning",
      "ai",
      "tensorflow",
      "pytorch",
      "langchain",
      "openai",
    ]

    return commonSkills.filter((skill) => query.toLowerCase().includes(skill))
  }

  const extractLocationFromQuery = (query: string): string | undefined => {
    const locations = [
      "europe",
      "usa",
      "canada",
      "uk",
      "germany",
      "france",
      "spain",
      "italy",
      "netherlands",
      "sweden",
      "australia",
      "india",
      "japan",
      "china",
      "brazil",
      "remote",
      "san francisco",
      "new york",
      "london",
      "berlin",
      "paris",
    ]

    const found = locations.find((location) => query.toLowerCase().includes(location))

    return found
  }

  const extractExperienceFromQuery = (query: string): string | undefined => {
    const match = query.match(/(\d+)\+?\s*years?/i)
    return match ? match[1] : undefined
  }

  const extractJobTitleFromQuery = (query: string): string | undefined => {
    const titles = [
      "engineer",
      "developer",
      "architect",
      "scientist",
      "analyst",
      "manager",
      "ai engineer",
      "ml engineer",
      "data scientist",
      "software engineer",
      "full stack",
      "frontend",
      "backend",
      "devops",
    ]

    const found = titles.find((title) => query.toLowerCase().includes(title))

    return found
  }

  const convertLinkedInProfileToCandidate = (profile: LinkedInProfile) => {
    // Extract years of experience
    const experienceMatch = profile.experience.match(/(\d+)/)
    const experienceYears = experienceMatch ? Number.parseInt(experienceMatch[1]) : 0

    // Generate a mock email
    const email = `${profile.name.toLowerCase().replace(/\s+/g, ".")}@email.com`

    return {
      email,
      full_name: profile.name,
      location: profile.location,
      skills: profile.skills,
      experience_years: experienceYears,
      current_position: profile.position,
      current_company: profile.company,
      education: [
        {
          degree: profile.education.split(" - ")[1] || "Degree",
          school: profile.education.split(" - ")[0] || "University",
          year: new Date().getFullYear() - experienceYears - 2,
          field: "Computer Science",
        },
      ],
      certifications: [],
      languages: ["English"],
      availability_status: "available" as const,
      resume_text: `${profile.headline}\n\n${profile.summary}\n\nEducation: ${profile.education}\nExperience: ${profile.experience}\nSkills: ${profile.skills.join(", ")}`,
      profile_image: profile.profileImage,
    }
  }

  const exampleQueries = [
    "Find AI engineers with LangChain experience in Europe",
    "Senior React developers with 5+ years experience",
    "Python developers with machine learning skills in San Francisco",
    "Full-stack engineers open to remote work",
    "Data scientists with PhD in statistics",
  ]

  return (
    <div className="space-y-6">
      {/* Search Interface */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Linkedin className="h-6 w-6 text-blue-600" />
              <CardTitle>LinkedIn Talent Search</CardTitle>
            </div>
            <Badge variant="outline" className="text-blue-600 border-blue-600">
              Premium Feature
            </Badge>
          </div>
          <CardDescription>
            Search LinkedIn for potential candidates matching your job requirements. Our AI will parse your natural
            language query and find the best matches.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              placeholder="e.g., Find AI engineers with LangChain experience in Europe"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && handleSearch()}
              className="flex-1"
            />
            <Button onClick={handleSearch} disabled={isSearching} className="bg-blue-600 hover:bg-blue-700">
              {isSearching ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Search className="h-4 w-4 mr-2" />}
              Search LinkedIn
            </Button>
          </div>

          {/* Example Queries */}
          <div className="space-y-2">
            <p className="text-sm text-gray-600">Try these example searches:</p>
            <div className="flex flex-wrap gap-2">
              {exampleQueries.map((example, index) => (
                <Badge
                  key={index}
                  variant="outline"
                  className="cursor-pointer hover:bg-gray-100"
                  onClick={() => setQuery(example)}
                >
                  {example}
                </Badge>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Search Progress */}
      {isSearching && (
        <Card>
          <CardContent className="py-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin text-blue-600" />
                  <span className="font-medium text-blue-600">{searchStatus}</span>
                </div>
              </div>
              <Progress
                value={searchStatus.includes("Connecting") ? 30 : searchStatus.includes("Searching") ? 60 : 90}
              />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Search Results */}
      {!isSearching && profiles.length > 0 && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>LinkedIn Search Results</CardTitle>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <span>{profiles.length} candidates found</span>
                <span>•</span>
                <span>{searchTime}ms</span>
              </div>
            </div>
            <CardDescription>
              These candidates were found on LinkedIn based on your search criteria. Add them to your database for
              future reference.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {profiles.map((profile) => (
                <div key={profile.name} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                  <div className="flex items-start gap-4">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={profile.profileImage || "/placeholder.svg"} alt={profile.name} />
                      <AvatarFallback>{profile.name.charAt(0)}</AvatarFallback>
                    </Avatar>

                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold text-lg">{profile.name}</h3>
                        <Badge variant="outline" className="text-blue-600 border-blue-600">
                          <Linkedin className="h-3 w-3 mr-1" />
                          LinkedIn
                        </Badge>
                      </div>

                      <p className="text-sm text-gray-600 mb-2">{profile.headline}</p>

                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <Briefcase className="h-3 w-3" />
                          <span>
                            {profile.position} at {profile.company}
                          </span>
                        </div>

                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <MapPin className="h-3 w-3" />
                          <span>{profile.location}</span>
                        </div>

                        <div className="flex flex-wrap gap-1 mt-2">
                          {profile.skills.slice(0, 5).map((skill, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {skill}
                            </Badge>
                          ))}
                          {profile.skills.length > 5 && (
                            <Badge variant="outline" className="text-xs">
                              +{profile.skills.length - 5} more
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="text-right space-y-1">
                      <div className="text-sm space-y-1">
                        <div className="flex items-center justify-end gap-1">
                          <span className="text-gray-600">Connections:</span>
                          <span className="font-medium">{profile.connections}+</span>
                        </div>
                        <div className="flex items-center justify-end gap-1">
                          <span className="text-gray-600">Recommendations:</span>
                          <span className="font-medium">{profile.recommendations}</span>
                        </div>
                        <div className="flex items-center justify-end gap-1">
                          <span className="text-gray-600">Experience:</span>
                          <span className="font-medium">{profile.experience}</span>
                        </div>
                      </div>

                      <div className="flex gap-2 justify-end mt-2">
                        <Button
                          size="sm"
                          onClick={() => handleAddToDatabase(profile)}
                          disabled={addingCandidates.has(profile.name.replace(/\s+/g, "-").toLowerCase())}
                          className="bg-blue-600 hover:bg-blue-700"
                        >
                          {addingCandidates.has(profile.name.replace(/\s+/g, "-").toLowerCase()) ? (
                            <Loader2 className="h-3 w-3 animate-spin mr-1" />
                          ) : (
                            <UserPlus className="h-3 w-3 mr-1" />
                          )}
                          Add to Database
                        </Button>
                        <Button size="sm" variant="outline">
                          <ExternalLink className="h-3 w-3 mr-1" />
                          View Profile
                        </Button>
                      </div>
                    </div>
                  </div>

                  {profile.summary && (
                    <div className="mt-3 p-3 bg-blue-50 rounded-md">
                      <p className="text-sm text-blue-800">
                        <strong>Summary:</strong> {profile.summary}
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
          <CardFooter className="border-t pt-4">
            <Alert className="w-full">
              <Linkedin className="h-4 w-4" />
              <AlertDescription>
                <strong>LinkedIn Integration:</strong> In production, this feature connects to LinkedIn's Recruiter API
                or uses a third-party scraping service with proper authentication. The current implementation uses mock
                data for demonstration purposes.
              </AlertDescription>
            </Alert>
          </CardFooter>
        </Card>
      )}

      {/* No Results */}
      {!isSearching && profiles.length === 0 && query && (
        <Card>
          <CardContent className="text-center py-12">
            <Linkedin className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No LinkedIn profiles found</h3>
            <p className="text-gray-600">Try adjusting your search criteria or using different keywords.</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
