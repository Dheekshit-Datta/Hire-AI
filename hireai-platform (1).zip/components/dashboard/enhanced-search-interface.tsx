"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Loader2,
  Search,
  Brain,
  MapPin,
  Clock,
  Star,
  AlertCircle,
  Linkedin,
  Users,
  ExternalLink,
  UserPlus,
  Sparkles,
  Zap,
} from "lucide-react"
import { searchCandidates } from "@/app/actions/search"
import type { CandidateScore } from "@/lib/types"

// Enhanced LinkedIn profiles with more realistic data
const mockLinkedInProfiles = [
  {
    id: "linkedin-1",
    name: "Sarah Chen",
    headline: "Senior AI Engineer at Google | Machine Learning Expert | LangChain Specialist",
    location: "San Francisco, CA",
    experience: "6+ years",
    skills: ["Python", "TensorFlow", "LangChain", "OpenAI", "Machine Learning", "Deep Learning", "NLP"],
    company: "Google",
    position: "Senior AI Engineer",
    profileUrl: "https://linkedin.com/in/sarah-chen-ai",
    summary:
      "Passionate AI engineer with 6+ years building production ML systems. Expert in LangChain and conversational AI platforms serving millions of users.",
    connections: 2847,
    isOpenToWork: false,
    avatar: "https://randomuser.me/api/portraits/women/32.jpg",
    score: 95,
  },
  {
    id: "linkedin-2",
    name: "Marcus Rodriguez",
    headline: "AI/ML Engineer | LangChain Expert | Building the Future of AI",
    location: "Berlin, Germany",
    experience: "5+ years",
    skills: ["Python", "LangChain", "OpenAI", "Vector Databases", "RAG", "Transformers", "FastAPI"],
    company: "DeepMind",
    position: "ML Research Engineer",
    profileUrl: "https://linkedin.com/in/marcus-rodriguez-ml",
    summary:
      "ML Research Engineer at DeepMind with expertise in large language models and retrieval-augmented generation. Published researcher with 15+ papers.",
    connections: 1523,
    isOpenToWork: false,
    avatar: "https://randomuser.me/api/portraits/men/45.jpg",
    score: 92,
  },
  {
    id: "linkedin-3",
    name: "Priya Patel",
    headline: "Principal AI Engineer | LangChain Expert | Conversational AI Leader",
    location: "London, United Kingdom",
    experience: "8+ years",
    skills: ["Python", "LangChain", "Hugging Face", "OpenAI", "Azure AI", "React", "TypeScript"],
    company: "Microsoft",
    position: "Principal AI Engineer",
    profileUrl: "https://linkedin.com/in/priya-patel-ai",
    summary:
      "Principal AI Engineer at Microsoft leading conversational AI initiatives. 8+ years of experience in enterprise AI solutions for Fortune 500 companies.",
    connections: 3241,
    isOpenToWork: false,
    avatar: "https://randomuser.me/api/portraits/women/65.jpg",
    score: 96,
  },
  {
    id: "linkedin-4",
    name: "Alex Thompson",
    headline: "Senior Software Engineer | AI/ML | LangChain Developer",
    location: "Toronto, Canada",
    experience: "7+ years",
    skills: ["Python", "LangChain", "OpenAI", "PostgreSQL", "Docker", "Kubernetes", "AWS"],
    company: "Shopify",
    position: "Senior AI Engineer",
    profileUrl: "https://linkedin.com/in/alex-thompson-dev",
    summary:
      "Full-stack engineer transitioning to AI with deep expertise in LangChain and production ML systems. Led development of e-commerce AI assistant.",
    connections: 650,
    isOpenToWork: true,
    avatar: "https://randomuser.me/api/portraits/men/22.jpg",
    score: 88,
  },
  {
    id: "linkedin-5",
    name: "Elena Kowalski",
    headline: "AI Research Engineer | LangChain | NLP Specialist",
    location: "Amsterdam, Netherlands",
    experience: "3+ years",
    skills: ["Python", "LangChain", "spaCy", "NLTK", "Transformers", "PyTorch", "Research"],
    company: "Booking.com",
    position: "AI Research Engineer",
    profileUrl: "https://linkedin.com/in/elena-kowalski",
    summary:
      "NLP researcher with practical experience in building LangChain applications for production use in travel technology.",
    connections: 480,
    isOpenToWork: true,
    avatar: "https://randomuser.me/api/portraits/women/42.jpg",
    score: 85,
  },
]

export default function EnhancedSearchInterface() {
  const [query, setQuery] = useState("")
  const [isSearching, setIsSearching] = useState(false)
  const [databaseResults, setDatabaseResults] = useState<CandidateScore[]>([])
  const [linkedinResults, setLinkedinResults] = useState<any[]>([])
  const [searchTime, setSearchTime] = useState<number>(0)
  const [searchError, setSearchError] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState("database")

  const handleSearch = async () => {
    if (!query.trim()) return

    setIsSearching(true)
    setSearchError(null)
    const startTime = Date.now()

    try {
      // Search database
      const dbResults = await searchCandidates(query)
      setDatabaseResults(dbResults)

      // Simulate LinkedIn search with filtered results based on query
      const filteredLinkedIn = mockLinkedInProfiles.filter((profile) => {
        const searchTerms = query.toLowerCase().split(" ")
        const profileText =
          `${profile.name} ${profile.headline} ${profile.skills.join(" ")} ${profile.location} ${profile.company}`.toLowerCase()
        return searchTerms.some((term) => profileText.includes(term))
      })

      // Sort by score
      filteredLinkedIn.sort((a, b) => b.score - a.score)

      setLinkedinResults(filteredLinkedIn)
      setSearchTime(Date.now() - startTime)

      // Auto-switch to tab with results
      if (filteredLinkedIn.length > 0 && dbResults.length === 0) {
        setActiveTab("linkedin")
      } else if (dbResults.length > 0) {
        setActiveTab("database")
      }
    } catch (error) {
      console.error("Search failed:", error)
      setSearchError("Search failed. Please try again.")
      setDatabaseResults([])
      setLinkedinResults([])
    } finally {
      setIsSearching(false)
    }
  }

  const handleAddToDatabase = (profile: any) => {
    alert(`Adding ${profile.name} to your database...`)
    // In a real app, this would call an API to add the candidate
  }

  const exampleQueries = [
    "AI engineers with LangChain experience",
    "Senior React developers with 5+ years",
    "Python developers with machine learning",
    "DevOps engineers with Kubernetes",
    "Full-stack engineers open to remote",
    "Data scientists with PhD",
  ]

  const totalResults = databaseResults.length + linkedinResults.length

  return (
    <div className="space-y-8">
      {/* Enhanced Search Interface */}
      <Card className="border-0 shadow-2xl bg-gradient-to-br from-white to-blue-50">
        <CardHeader className="pb-6">
          <CardTitle className="flex items-center gap-3 text-2xl">
            <div className="relative">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl flex items-center justify-center">
                <Brain className="h-5 w-5 text-white" />
              </div>
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-yellow-400 rounded-full flex items-center justify-center">
                <Sparkles className="h-2 w-2 text-white" />
              </div>
            </div>
            AI-Powered Multi-Source Search
          </CardTitle>
          <CardDescription className="text-lg text-gray-600">
            Search across your database and LinkedIn simultaneously. Our AI finds the best matching candidates from both
            sources with advanced scoring.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex gap-3">
            <Input
              placeholder="e.g., Find AI engineers with LangChain experience in Europe"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && handleSearch()}
              className="flex-1 h-14 text-lg border-2 border-gray-200 focus:border-blue-500 rounded-xl"
            />
            <Button
              onClick={handleSearch}
              disabled={isSearching}
              className="h-14 px-8 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all transform hover:scale-105"
            >
              {isSearching ? (
                <div className="flex items-center gap-2">
                  <Loader2 className="h-5 w-5 animate-spin" />
                  Searching...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Search className="h-5 w-5" />
                  Search All Sources
                </div>
              )}
            </Button>
          </div>

          {searchError && (
            <Alert variant="destructive" className="border-red-200 bg-red-50">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription className="text-red-800">{searchError}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-3">
            <p className="text-sm text-gray-600 font-medium">Try these example searches:</p>
            <div className="flex flex-wrap gap-2">
              {exampleQueries.map((example, index) => (
                <Badge
                  key={index}
                  variant="outline"
                  className="cursor-pointer hover:bg-blue-50 hover:border-blue-300 transition-all px-3 py-1 text-sm"
                  onClick={() => setQuery(example)}
                >
                  {example}
                </Badge>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Search Results */}
      {totalResults > 0 && (
        <Card className="border-0 shadow-2xl">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center justify-between text-xl">
              <div className="flex items-center gap-3">
                <Zap className="h-6 w-6 text-yellow-500" />
                <span>Multi-Source Search Results</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600 bg-gray-100 px-3 py-1 rounded-full">
                <Clock className="h-4 w-4" />
                {searchTime}ms
              </div>
            </CardTitle>
            <CardDescription className="text-lg">
              Found <span className="font-semibold text-blue-600">{totalResults}</span> candidates across all sources
            </CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <div className="border-b px-6">
                <TabsList className="h-14 w-full rounded-none bg-transparent border-b">
                  <TabsTrigger
                    value="database"
                    className="data-[state=active]:border-b-2 data-[state=active]:border-blue-600 data-[state=active]:shadow-none rounded-none h-14 flex items-center gap-3 text-lg font-medium"
                  >
                    <Users className="h-5 w-5" />
                    Your Database ({databaseResults.length})
                  </TabsTrigger>
                  <TabsTrigger
                    value="linkedin"
                    className="data-[state=active]:border-b-2 data-[state=active]:border-blue-600 data-[state=active]:shadow-none rounded-none h-14 flex items-center gap-3 text-lg font-medium"
                  >
                    <Linkedin className="h-5 w-5" />
                    LinkedIn ({linkedinResults.length})
                  </TabsTrigger>
                </TabsList>
              </div>

              <TabsContent value="database" className="p-0 m-0">
                <div className="p-6">
                  {databaseResults.length === 0 ? (
                    <div className="text-center py-12">
                      <Users className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">No candidates found in your database</h3>
                      <p className="text-gray-500">Try searching LinkedIn or add more candidates to your database.</p>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      {databaseResults.map((result) => (
                        <DatabaseCandidateCard key={result.id} result={result} />
                      ))}
                    </div>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="linkedin" className="p-0 m-0">
                <div className="p-6">
                  {linkedinResults.length === 0 ? (
                    <div className="text-center py-12">
                      <Linkedin className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">No LinkedIn profiles found</h3>
                      <p className="text-gray-500">Try different search terms or check your LinkedIn integration.</p>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      <Alert className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
                        <Linkedin className="h-5 w-5 text-blue-600" />
                        <AlertDescription className="text-blue-800 text-lg">
                          <strong>LinkedIn Integration Active:</strong> These profiles were scraped from LinkedIn based
                          on your search. Click "Add to Database" to import them.
                        </AlertDescription>
                      </Alert>
                      {linkedinResults.map((profile) => (
                        <LinkedInCandidateCard
                          key={profile.id}
                          profile={profile}
                          onAdd={() => handleAddToDatabase(profile)}
                        />
                      ))}
                    </div>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      )}

      {/* No Results */}
      {!isSearching && totalResults === 0 && query && !searchError && (
        <Card className="border-0 shadow-xl">
          <CardContent className="text-center py-16">
            <Search className="h-16 w-16 text-gray-400 mx-auto mb-6" />
            <h3 className="text-2xl font-semibold text-gray-900 mb-4">No candidates found</h3>
            <p className="text-gray-600 text-lg mb-6">
              Try adjusting your search criteria or using different keywords.
            </p>
            <div className="bg-gray-50 rounded-xl p-6 max-w-md mx-auto">
              <p className="text-sm text-gray-600 font-medium mb-3">Suggestions:</p>
              <ul className="text-sm text-gray-600 space-y-2 text-left">
                <li>• Use broader skill terms (e.g., "JavaScript" instead of "React.js")</li>
                <li>• Try different location formats (e.g., "Europe" instead of "EU")</li>
                <li>• Remove specific experience requirements</li>
                <li>• Check spelling and try synonyms</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

interface DatabaseCandidateCardProps {
  result: CandidateScore
}

function DatabaseCandidateCard({ result }: DatabaseCandidateCardProps) {
  return (
    <div className="border-2 border-gray-100 rounded-2xl p-6 hover:border-blue-200 hover:shadow-xl transition-all duration-300 bg-gradient-to-br from-white to-gray-50">
      <div className="flex items-start justify-between">
        <div className="flex items-start gap-4 flex-1">
          <Avatar className="h-16 w-16 border-2 border-gray-200">
            <AvatarImage src="/placeholder.svg" alt={result.candidate?.full_name} />
            <AvatarFallback className="text-lg font-semibold bg-gradient-to-br from-blue-500 to-purple-500 text-white">
              {result.candidate?.full_name?.charAt(0) || "C"}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-3">
              <h3 className="font-bold text-xl text-gray-900">{result.candidate?.full_name}</h3>
              <div className="flex items-center gap-1 bg-yellow-100 px-2 py-1 rounded-full">
                <Star className="h-4 w-4 text-yellow-600 fill-current" />
                <span className="font-bold text-yellow-700">{result.overall_score.toFixed(1)}</span>
              </div>
              <Badge variant="outline" className="text-blue-600 border-blue-200 bg-blue-50 font-medium">
                <Users className="h-3 w-3 mr-1" />
                Database
              </Badge>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-2 text-gray-700">
                <span className="font-medium">{result.candidate?.current_position}</span>
                {result.candidate?.current_company && (
                  <>
                    <span>at</span>
                    <span className="font-semibold text-blue-600">{result.candidate.current_company}</span>
                  </>
                )}
              </div>

              {result.candidate?.location && (
                <div className="flex items-center gap-2 text-gray-600">
                  <MapPin className="h-4 w-4" />
                  {result.candidate.location}
                </div>
              )}

              <div className="flex flex-wrap gap-2">
                {result.candidate?.skills.slice(0, 5).map((skill, index) => (
                  <Badge key={index} variant="secondary" className="text-sm font-medium">
                    {skill}
                  </Badge>
                ))}
                {result.candidate?.skills.length > 5 && (
                  <Badge variant="outline" className="text-sm">
                    +{result.candidate.skills.length - 5} more
                  </Badge>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="text-right space-y-2">
          <div className="text-sm bg-gray-50 rounded-lg p-3">
            <div className="font-medium">Skills: {result.skill_match_score.toFixed(1)}</div>
            <div className="font-medium">Experience: {result.experience_score.toFixed(1)}</div>
            <div className="font-medium">Location: {result.location_score.toFixed(1)}</div>
          </div>
          <Button size="sm" variant="outline" className="w-full font-medium">
            View Profile
          </Button>
        </div>
      </div>

      {result.ai_reasoning && (
        <div className="mt-4 p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl border border-blue-200">
          <p className="text-sm text-blue-800">
            <strong>AI Analysis:</strong> {result.ai_reasoning}
          </p>
        </div>
      )}
    </div>
  )
}

interface LinkedInCandidateCardProps {
  profile: any
  onAdd: () => void
}

function LinkedInCandidateCard({ profile, onAdd }: LinkedInCandidateCardProps) {
  return (
    <div className="border-2 border-gray-100 rounded-2xl p-6 hover:border-blue-200 hover:shadow-xl transition-all duration-300 bg-gradient-to-br from-white to-blue-50">
      <div className="flex items-start justify-between">
        <div className="flex items-start gap-4 flex-1">
          <Avatar className="h-16 w-16 border-2 border-blue-200">
            <AvatarImage src={profile.avatar || "/placeholder.svg"} alt={profile.name} />
            <AvatarFallback className="text-lg font-semibold bg-gradient-to-br from-blue-500 to-purple-500 text-white">
              {profile.name.charAt(0)}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-3">
              <h3 className="font-bold text-xl text-gray-900">{profile.name}</h3>
              <div className="flex items-center gap-1 bg-yellow-100 px-2 py-1 rounded-full">
                <Star className="h-4 w-4 text-yellow-600 fill-current" />
                <span className="font-bold text-yellow-700">{profile.score}</span>
              </div>
              <Badge variant="outline" className="text-blue-600 border-blue-200 bg-blue-50 font-medium">
                <Linkedin className="h-3 w-3 mr-1" />
                LinkedIn
              </Badge>
              {profile.isOpenToWork && (
                <Badge className="bg-green-100 text-green-800 border-green-200 font-medium">Open to Work</Badge>
              )}
            </div>

            <div className="space-y-3">
              <p className="text-gray-700 font-medium line-clamp-2">{profile.headline}</p>

              <div className="flex items-center gap-2 text-gray-700">
                <span className="font-medium">{profile.position}</span>
                {profile.company && (
                  <>
                    <span>at</span>
                    <span className="font-semibold text-blue-600">{profile.company}</span>
                  </>
                )}
              </div>

              {profile.location && (
                <div className="flex items-center gap-2 text-gray-600">
                  <MapPin className="h-4 w-4" />
                  {profile.location}
                </div>
              )}

              <div className="flex flex-wrap gap-2">
                {profile.skills.slice(0, 5).map((skill: string, index: number) => (
                  <Badge key={index} variant="secondary" className="text-sm font-medium">
                    {skill}
                  </Badge>
                ))}
                {profile.skills.length > 5 && (
                  <Badge variant="outline" className="text-sm">
                    +{profile.skills.length - 5} more
                  </Badge>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="text-right space-y-3">
          <div className="text-sm bg-gray-50 rounded-lg p-3">
            <div className="font-medium">Connections: {profile.connections.toLocaleString()}+</div>
            {profile.experience && <div className="font-medium">Experience: {profile.experience}</div>}
          </div>
          <div className="flex flex-col gap-2">
            <Button size="sm" variant="outline" className="font-medium">
              <ExternalLink className="h-3 w-3 mr-1" />
              View LinkedIn
            </Button>
            <Button
              size="sm"
              onClick={onAdd}
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-medium"
            >
              <UserPlus className="h-3 w-3 mr-1" />
              Add to Database
            </Button>
          </div>
        </div>
      </div>

      {profile.summary && (
        <div className="mt-4 p-4 bg-gradient-to-r from-gray-50 to-blue-50 rounded-xl border border-gray-200">
          <p className="text-sm text-gray-700 line-clamp-3">{profile.summary}</p>
        </div>
      )}
    </div>
  )
}
