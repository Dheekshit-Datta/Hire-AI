"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Loader2, Search, MapPin, Briefcase, Linkedin, ExternalLink, UserPlus, Clock, Filter } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { performLinkedInSearch, addLinkedInCandidateToDatabase } from "@/app/actions/real-linkedin-search"
import type { LinkedInProfile } from "@/lib/services/real-linkedin-api"
import { convertLinkedInProfileToCandidate } from "@/lib/services/real-linkedin-api"
import { Skeleton } from "@/components/ui/skeleton"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"

export default function ModernLinkedInSearch() {
  const [query, setQuery] = useState("")
  const [isSearching, setIsSearching] = useState(false)
  const [profiles, setProfiles] = useState<LinkedInProfile[]>([])
  const [addingCandidates, setAddingCandidates] = useState<Set<string>>(new Set())
  const [searchTime, setSearchTime] = useState<number>(0)
  const [searchStatus, setSearchStatus] = useState<string>("")
  const [progress, setProgress] = useState(0)
  const [activeTab, setActiveTab] = useState("all")
  const [savedProfiles, setSavedProfiles] = useState<LinkedInProfile[]>([])
  const [filters, setFilters] = useState({
    location: "",
    experience: "",
    industry: "",
    company: "",
  })
  const [showFilters, setShowFilters] = useState(false)

  // Simulate progress animation
  useEffect(() => {
    let interval: NodeJS.Timeout

    if (isSearching) {
      interval = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 95) {
            clearInterval(interval)
            return 95
          }
          return prev + 5
        })
      }, 300)
    } else if (progress > 0) {
      setProgress(100)
      const timeout = setTimeout(() => setProgress(0), 1000)
      return () => clearTimeout(timeout)
    }

    return () => clearInterval(interval)
  }, [isSearching, progress])

  const handleSearch = async () => {
    if (!query.trim()) return

    setIsSearching(true)
    setSearchStatus("Connecting to LinkedIn API...")
    setProfiles([])
    setProgress(10)

    const startTime = Date.now()

    try {
      // Parse the query to extract skills, location, etc.
      setSearchStatus("Analyzing search query...")
      setProgress(30)

      await new Promise((resolve) => setTimeout(resolve, 500))
      setSearchStatus("Searching LinkedIn profiles...")
      setProgress(50)

      await new Promise((resolve) => setTimeout(resolve, 500))
      setSearchStatus("Processing results...")
      setProgress(70)

      // Search LinkedIn profiles with real API (includes fallback)
      const results = await performLinkedInSearch({
        query,
        location: filters.location,
        experience: filters.experience,
        industry: filters.industry,
        company: filters.company,
        skills: extractSkillsFromQuery(query),
      })

      setProfiles(results.profiles)
      setSearchTime(results.searchTime)
      setProgress(100)

      if (results.profiles.length === 0) {
        setSearchStatus("No profiles found. Try adjusting your search criteria.")
      } else {
        setSearchStatus(`Found ${results.profiles.length} candidates`)
      }
    } catch (error) {
      console.error("LinkedIn search failed:", error)
      setSearchStatus("Search temporarily using demo data. LinkedIn API may be unavailable.")
      // Don't show error to user, the fallback system should handle this gracefully
    } finally {
      setIsSearching(false)
    }
  }

  const handleAddToDatabase = async (profile: LinkedInProfile) => {
    const profileId = profile.id
    setAddingCandidates((prev) => new Set(prev).add(profileId))

    try {
      const candidateData = convertLinkedInProfileToCandidate(profile)
      await addLinkedInCandidateToDatabase(candidateData)

      // Add to saved profiles and remove from search results
      setSavedProfiles((prev) => [...prev, profile])
      setProfiles((prev) => prev.filter((p) => p.id !== profile.id))

      // Show success message
      setSearchStatus(`Added ${profile.name} to your database!`)
      setTimeout(() => setSearchStatus(""), 3000)
    } catch (error) {
      console.error("Failed to add candidate:", error)
      setSearchStatus("Failed to add candidate. Please try again.")
    } finally {
      setAddingCandidates((prev) => {
        const newSet = new Set(prev)
        newSet.delete(profileId)
        return newSet
      })
    }
  }

  // Helper functions to extract information from the query
  const extractSkillsFromQuery = (query: string): string[] => {
    const commonSkills = [
      "javascript",
      "python",
      "react",
      "node",
      "typescript",
      "java",
      "c++",
      "sql",
      "aws",
      "docker",
      "kubernetes",
      "git",
      "mongodb",
      "postgresql",
      "redis",
      "machine learning",
      "ai",
      "tensorflow",
      "pytorch",
      "langchain",
      "openai",
    ]

    return commonSkills.filter((skill) => query.toLowerCase().includes(skill))
  }

  const exampleQueries = [
    "Find AI engineers with LangChain experience in Europe",
    "Senior React developers with 5+ years experience",
    "Python developers with machine learning skills in San Francisco",
    "Full-stack engineers open to remote work",
    "Data scientists with PhD in statistics",
  ]

  const industries = [
    "Technology",
    "Finance",
    "Healthcare",
    "Education",
    "Manufacturing",
    "Retail",
    "Media",
    "Consulting",
    "Government",
    "Non-profit",
  ]

  const experienceLevels = [
    "Entry level (0-2 years)",
    "Mid-level (3-5 years)",
    "Senior (6-10 years)",
    "Director (10+ years)",
    "Executive (15+ years)",
  ]

  return (
    <div className="space-y-6">
      {/* Demo Notice */}
      <Alert className="bg-blue-50 border-blue-200">
        <Linkedin className="h-4 w-4 text-blue-600" />
        <AlertDescription className="text-blue-800">
          <strong>Demo Mode:</strong> This LinkedIn search feature demonstrates our AI-powered talent discovery
          capabilities. In production, this connects to LinkedIn's API or professional scraping services. Currently
          showing enhanced demo data that adapts to your search criteria.
        </AlertDescription>
      </Alert>

      {/* Header Card with Search */}
      <Card className="overflow-hidden border-none shadow-lg bg-gradient-to-r from-blue-50 to-indigo-50">
        <CardHeader className="pb-0">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-2xl font-bold text-gray-800 flex items-center gap-2">
                <Linkedin className="h-6 w-6 text-blue-600" />
                LinkedIn Talent Search
              </CardTitle>
              <CardDescription className="text-gray-600 mt-1">
                Find and connect with top talent directly from LinkedIn
              </CardDescription>
            </div>
            <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200 px-3 py-1">
              Demo Feature
            </Badge>
          </div>
        </CardHeader>

        <CardContent className="pt-6">
          <div className="relative">
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                <Input
                  placeholder="Search for candidates (e.g., 'AI engineers with LangChain experience in Europe')"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && handleSearch()}
                  className="pl-10 pr-4 py-6 text-base border-gray-200 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                />
              </div>

              <Popover open={showFilters} onOpenChange={setShowFilters}>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="gap-2 border-gray-200 hover:bg-gray-50">
                    <Filter className="h-4 w-4" />
                    Filters
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-80 p-4">
                  <div className="space-y-4">
                    <h3 className="font-medium text-sm">Refine your search</h3>

                    <div className="space-y-2">
                      <Label htmlFor="location">Location</Label>
                      <Input
                        id="location"
                        placeholder="e.g., San Francisco, Europe"
                        value={filters.location}
                        onChange={(e) => setFilters({ ...filters, location: e.target.value })}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="experience">Experience Level</Label>
                      <Select
                        value={filters.experience}
                        onValueChange={(value) => setFilters({ ...filters, experience: value })}
                      >
                        <SelectTrigger id="experience">
                          <SelectValue placeholder="Select experience level" />
                        </SelectTrigger>
                        <SelectContent>
                          {experienceLevels.map((level) => (
                            <SelectItem key={level} value={level}>
                              {level}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="industry">Industry</Label>
                      <Select
                        value={filters.industry}
                        onValueChange={(value) => setFilters({ ...filters, industry: value })}
                      >
                        <SelectTrigger id="industry">
                          <SelectValue placeholder="Select industry" />
                        </SelectTrigger>
                        <SelectContent>
                          {industries.map((industry) => (
                            <SelectItem key={industry} value={industry}>
                              {industry}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="company">Current Company</Label>
                      <Input
                        id="company"
                        placeholder="e.g., Google, Microsoft"
                        value={filters.company}
                        onChange={(e) => setFilters({ ...filters, company: e.target.value })}
                      />
                    </div>

                    <div className="flex justify-end gap-2 pt-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setFilters({ location: "", experience: "", industry: "", company: "" })}
                      >
                        Reset
                      </Button>
                      <Button size="sm" onClick={() => setShowFilters(false)}>
                        Apply Filters
                      </Button>
                    </div>
                  </div>
                </PopoverContent>
              </Popover>

              <Button
                onClick={handleSearch}
                disabled={isSearching || !query.trim()}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6"
              >
                {isSearching ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    Searching...
                  </>
                ) : (
                  <>
                    <Search className="h-4 w-4 mr-2" />
                    Search
                  </>
                )}
              </Button>
            </div>

            {/* Example Queries */}
            <div className="mt-4">
              <p className="text-xs text-gray-500 mb-2">Try these examples:</p>
              <div className="flex flex-wrap gap-2">
                {exampleQueries.map((example, index) => (
                  <Badge
                    key={index}
                    variant="outline"
                    className="cursor-pointer bg-white hover:bg-gray-50 text-gray-700"
                    onClick={() => setQuery(example)}
                  >
                    {example}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        </CardContent>

        {/* Progress Bar */}
        {(isSearching || progress > 0) && (
          <div className="px-6 pb-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-blue-700 font-medium">{searchStatus}</span>
              <span className="text-sm text-gray-500">{progress}%</span>
            </div>
            <Progress value={progress} className="h-1.5" />
          </div>
        )}
      </Card>

      {/* Search Results */}
      {(profiles.length > 0 || savedProfiles.length > 0) && (
        <Card className="border-none shadow-lg">
          <CardHeader className="border-b bg-gray-50">
            <div className="flex items-center justify-between">
              <CardTitle className="text-xl font-semibold text-gray-800">LinkedIn Search Results</CardTitle>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Clock className="h-4 w-4" />
                <span>{searchTime}ms</span>
                <span className="mx-1">•</span>
                <span>{profiles.length + savedProfiles.length} candidates found</span>
              </div>
            </div>
          </CardHeader>

          <CardContent className="p-0">
            <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="w-full">
              <div className="border-b">
                <TabsList className="h-12 w-full rounded-none bg-transparent border-b">
                  <TabsTrigger
                    value="all"
                    className="data-[state=active]:border-b-2 data-[state=active]:border-blue-600 data-[state=active]:shadow-none rounded-none h-12"
                  >
                    All Results ({profiles.length + savedProfiles.length})
                  </TabsTrigger>
                  <TabsTrigger
                    value="saved"
                    className="data-[state=active]:border-b-2 data-[state=active]:border-blue-600 data-[state=active]:shadow-none rounded-none h-12"
                  >
                    Saved ({savedProfiles.length})
                  </TabsTrigger>
                </TabsList>
              </div>

              <TabsContent value="all" className="p-0 m-0">
                <div className="divide-y">
                  {profiles.length === 0 && savedProfiles.length === 0 ? (
                    <div className="py-12 text-center">
                      <p className="text-gray-500">No results found. Try a different search query.</p>
                    </div>
                  ) : (
                    [...profiles, ...savedProfiles].map((profile) => (
                      <ProfileCard
                        key={profile.id}
                        profile={profile}
                        onAdd={handleAddToDatabase}
                        isAdding={addingCandidates.has(profile.id)}
                        isSaved={savedProfiles.some((p) => p.id === profile.id)}
                      />
                    ))
                  )}
                </div>
              </TabsContent>

              <TabsContent value="saved" className="p-0 m-0">
                <div className="divide-y">
                  {savedProfiles.length === 0 ? (
                    <div className="py-12 text-center">
                      <p className="text-gray-500">No saved profiles yet. Add candidates from your search results.</p>
                    </div>
                  ) : (
                    savedProfiles.map((profile) => <ProfileCard key={profile.id} profile={profile} isSaved={true} />)
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>

          <CardFooter className="bg-gray-50 border-t p-4">
            <Alert className="bg-blue-50 border-blue-100 text-blue-800">
              <Linkedin className="h-4 w-4 text-blue-600" />
              <AlertDescription>
                <span className="font-medium">LinkedIn Integration:</span> This feature connects to LinkedIn's API to
                find potential candidates matching your search criteria.
              </AlertDescription>
            </Alert>
          </CardFooter>
        </Card>
      )}

      {/* No Results */}
      {!isSearching && profiles.length === 0 && savedProfiles.length === 0 && query && (
        <Card className="border-none shadow-lg">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <div className="bg-gray-100 rounded-full p-4 mb-4">
              <Search className="h-8 w-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">No LinkedIn profiles found</h3>
            <p className="text-gray-600 max-w-md text-center">
              Try adjusting your search criteria or using different keywords to find more candidates.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Loading State */}
      {isSearching && profiles.length === 0 && (
        <Card className="border-none shadow-lg">
          <CardHeader className="border-b bg-gray-50">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Skeleton className="h-6 w-40" />
              </div>
              <Skeleton className="h-4 w-24" />
            </div>
          </CardHeader>
          <CardContent className="p-6 space-y-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex gap-4">
                <Skeleton className="h-12 w-12 rounded-full" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-5 w-48" />
                  <Skeleton className="h-4 w-72" />
                  <div className="flex gap-2">
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-4 w-32" />
                  </div>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <Skeleton className="h-4 w-20" />
                  <Skeleton className="h-9 w-28" />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  )
}

interface ProfileCardProps {
  profile: LinkedInProfile
  onAdd?: (profile: LinkedInProfile) => void
  isAdding?: boolean
  isSaved?: boolean
}

function ProfileCard({ profile, onAdd, isAdding = false, isSaved = false }: ProfileCardProps) {
  return (
    <div className="p-6 hover:bg-gray-50 transition-colors">
      <div className="flex items-start gap-4">
        <Avatar className="h-14 w-14 border">
          <AvatarImage src={profile.profileImage || "/placeholder.svg?height=56&width=56"} alt={profile.name} />
          <AvatarFallback className="bg-blue-100 text-blue-800 font-medium">
            {profile.name
              .split(" ")
              .map((n) => n[0])
              .join("")}
          </AvatarFallback>
        </Avatar>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            <h3 className="font-semibold text-lg text-gray-900 truncate">{profile.name}</h3>
            <Badge variant="outline" className="text-blue-600 border-blue-200 bg-blue-50">
              <Linkedin className="h-3 w-3 mr-1" />
              LinkedIn
            </Badge>
            {profile.isOpenToWork && (
              <Badge className="bg-green-100 text-green-800 border-green-200 hover:bg-green-200">Open to Work</Badge>
            )}
          </div>

          <p className="text-sm text-gray-700 mb-2 line-clamp-2">{profile.headline}</p>

          <div className="flex flex-wrap gap-y-2 gap-x-4 text-sm text-gray-600 mb-3">
            {profile.company && (
              <div className="flex items-center gap-1">
                <Briefcase className="h-3.5 w-3.5 text-gray-500" />
                <span className="truncate max-w-[200px]">
                  {profile.position} at {profile.company}
                </span>
              </div>
            )}

            {profile.location && (
              <div className="flex items-center gap-1">
                <MapPin className="h-3.5 w-3.5 text-gray-500" />
                <span className="truncate max-w-[200px]">{profile.location}</span>
              </div>
            )}

            {profile.experience && (
              <div className="flex items-center gap-1">
                <Clock className="h-3.5 w-3.5 text-gray-500" />
                <span>{profile.experience}</span>
              </div>
            )}
          </div>

          <div className="flex flex-wrap gap-1.5 mb-4">
            {profile.skills.slice(0, 5).map((skill, index) => (
              <Badge key={index} variant="secondary" className="text-xs bg-gray-100 text-gray-700 hover:bg-gray-200">
                {skill}
              </Badge>
            ))}
            {profile.skills.length > 5 && (
              <Badge variant="outline" className="text-xs">
                +{profile.skills.length - 5} more
              </Badge>
            )}
          </div>

          {profile.summary && <p className="text-sm text-gray-600 line-clamp-2 mb-3">{profile.summary}</p>}
        </div>

        <div className="flex flex-col items-end gap-2 ml-4">
          <div className="text-sm space-y-1 text-right">
            <div className="flex items-center justify-end gap-1">
              <span className="text-gray-500">Connections:</span>
              <span className="font-medium">{profile.connections.toLocaleString()}+</span>
            </div>
            {profile.recommendations > 0 && (
              <div className="flex items-center justify-end gap-1">
                <span className="text-gray-500">Recommendations:</span>
                <span className="font-medium">{profile.recommendations}</span>
              </div>
            )}
          </div>

          <div className="flex gap-2 mt-2">
            {!isSaved && onAdd && (
              <Button
                onClick={() => onAdd(profile)}
                disabled={isAdding}
                className="bg-blue-600 hover:bg-blue-700 text-white"
                size="sm"
              >
                {isAdding ? (
                  <>
                    <Loader2 className="h-3.5 w-3.5 animate-spin mr-1" />
                    Adding...
                  </>
                ) : (
                  <>
                    <UserPlus className="h-3.5 w-3.5 mr-1" />
                    Add to Database
                  </>
                )}
              </Button>
            )}

            <Button
              variant="outline"
              size="sm"
              className="border-gray-200"
              onClick={() => window.open(profile.profileUrl, "_blank")}
            >
              <ExternalLink className="h-3.5 w-3.5 mr-1" />
              View Profile
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
