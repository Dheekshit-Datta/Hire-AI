"use client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import { TrendingUp, Users, Search, Briefcase } from "lucide-react"

const mockSearchData = [
  { month: "Jan", searches: 45, candidates: 120 },
  { month: "Feb", searches: 52, candidates: 135 },
  { month: "Mar", searches: 48, candidates: 128 },
  { month: "Apr", searches: 61, candidates: 142 },
  { month: "May", searches: 55, candidates: 138 },
  { month: "Jun", searches: 67, candidates: 155 },
]

const mockSkillsData = [
  { skill: "JavaScript", count: 45, color: "#8884d8" },
  { skill: "Python", count: 38, color: "#82ca9d" },
  { skill: "React", count: 32, color: "#ffc658" },
  { skill: "Node.js", count: 28, color: "#ff7300" },
  { skill: "TypeScript", count: 25, color: "#00ff00" },
]

const mockLocationData = [
  { location: "United States", count: 85 },
  { location: "Europe", count: 62 },
  { location: "Canada", count: 34 },
  { location: "Asia", count: 28 },
  { location: "Australia", count: 15 },
]

export default function AnalyticsDashboard() {
  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Searches</CardTitle>
            <Search className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">328</div>
            <p className="text-xs text-muted-foreground">+12% from last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg. Match Score</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">78.5</div>
            <p className="text-xs text-muted-foreground">+2.1% from last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Candidates</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,234</div>
            <p className="text-xs text-muted-foreground">+8% from last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Placements</CardTitle>
            <Briefcase className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">42</div>
            <p className="text-xs text-muted-foreground">+18% from last month</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Search Trends */}
        <Card>
          <CardHeader>
            <CardTitle>Search Activity</CardTitle>
            <CardDescription>Monthly search trends and candidate discoveries</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={mockSearchData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="searches" stroke="#8884d8" strokeWidth={2} />
                <Line type="monotone" dataKey="candidates" stroke="#82ca9d" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Top Skills */}
        <Card>
          <CardHeader>
            <CardTitle>Most Searched Skills</CardTitle>
            <CardDescription>Popular skills in your search queries</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={mockSkillsData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="skill" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="count" fill="#8884d8" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Location Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Candidate Locations</CardTitle>
            <CardDescription>Geographic distribution of candidates</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={mockSkillsData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ skill, percent }) => `${skill} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="count"
                >
                  {mockSkillsData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Search Queries</CardTitle>
            <CardDescription>Your latest AI-powered searches</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { query: "Senior React developers in San Francisco", results: 23, time: "2 hours ago" },
                { query: "Python ML engineers with PhD", results: 15, time: "4 hours ago" },
                { query: "Full-stack developers remote work", results: 67, time: "6 hours ago" },
                { query: "DevOps engineers with Kubernetes", results: 31, time: "1 day ago" },
                { query: "Data scientists in Europe", results: 42, time: "2 days ago" },
              ].map((search, index) => (
                <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <p className="font-medium text-sm">{search.query}</p>
                    <p className="text-xs text-gray-600">
                      {search.results} results • {search.time}
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-medium">{search.results}</div>
                    <div className="text-xs text-gray-600">matches</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
