"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { MessageSquare, Clock, AlertTriangle, CheckCircle, Brain } from "lucide-react"
import { generateInterviewSession } from "@/app/actions/search"
import { analyzeInterviewResponse } from "@/app/actions/interview"

interface InterviewSystemProps {
  candidateId: string
  jobPostingId: string
}

export default function InterviewSystem({ candidateId, jobPostingId }: InterviewSystemProps) {
  const [session, setSession] = useState<any>(null)
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [answers, setAnswers] = useState<string[]>([])
  const [currentAnswer, setCurrentAnswer] = useState("")
  const [analysis, setAnalysis] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [sessionComplete, setSessionComplete] = useState(false)

  const startInterview = async (sessionType: "pre_screening" | "technical" | "behavioral") => {
    setLoading(true)
    try {
      const newSession = await generateInterviewSession(candidateId, jobPostingId, sessionType)
      setSession(newSession)
      setAnswers(new Array(newSession.questions.length).fill(""))
    } catch (error) {
      console.error("Failed to start interview:", error)
    } finally {
      setLoading(false)
    }
  }

  const submitAnswer = async () => {
    if (!currentAnswer.trim() || !session) return

    setLoading(true)
    try {
      const question = session.questions[currentQuestionIndex]
      const response = await analyzeInterviewResponse(
        question.question,
        currentAnswer,
        question.expected_topics,
        question.evaluation_criteria,
        { id: candidateId }, // Simplified candidate object
      )

      const newAnswers = [...answers]
      newAnswers[currentQuestionIndex] = currentAnswer
      setAnswers(newAnswers)

      const newAnalysis = [...analysis]
      newAnalysis[currentQuestionIndex] = response
      setAnalysis(newAnalysis)

      setCurrentAnswer("")

      if (currentQuestionIndex < session.questions.length - 1) {
        setCurrentQuestionIndex(currentQuestionIndex + 1)
      } else {
        setSessionComplete(true)
      }
    } catch (error) {
      console.error("Failed to analyze answer:", error)
    } finally {
      setLoading(false)
    }
  }

  const getOverallScore = () => {
    if (analysis.length === 0) return 0
    const totalScore = analysis.reduce((sum, a) => sum + (a?.overall_score || 0), 0)
    return Math.round(totalScore / analysis.length)
  }

  const getCheatingIndicators = () => {
    return analysis.flatMap((a) => a?.cheating_indicators || [])
  }

  if (!session) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5" />
            AI Interview System
          </CardTitle>
          <CardDescription>
            Start an AI-powered interview session with adaptive questions and real-time analysis
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button
              onClick={() => startInterview("pre_screening")}
              disabled={loading}
              className="h-20 flex flex-col items-center justify-center"
            >
              <MessageSquare className="h-6 w-6 mb-2" />
              Pre-screening
              <span className="text-xs opacity-75">Basic fit assessment</span>
            </Button>

            <Button
              onClick={() => startInterview("technical")}
              disabled={loading}
              variant="outline"
              className="h-20 flex flex-col items-center justify-center"
            >
              <Brain className="h-6 w-6 mb-2" />
              Technical
              <span className="text-xs opacity-75">Skills evaluation</span>
            </Button>

            <Button
              onClick={() => startInterview("behavioral")}
              disabled={loading}
              variant="outline"
              className="h-20 flex flex-col items-center justify-center"
            >
              <CheckCircle className="h-6 w-6 mb-2" />
              Behavioral
              <span className="text-xs opacity-75">Culture fit assessment</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (sessionComplete) {
    const overallScore = getOverallScore()
    const cheatingIndicators = getCheatingIndicators()

    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-green-600" />
            Interview Complete
          </CardTitle>
          <CardDescription>AI analysis and scoring results</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Overall Score */}
          <div className="text-center">
            <div className="text-4xl font-bold text-blue-600 mb-2">{overallScore}/100</div>
            <p className="text-gray-600">Overall Interview Score</p>
          </div>

          {/* Cheating Detection */}
          {cheatingIndicators.length > 0 && (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                <strong>Potential Issues Detected:</strong>
                <ul className="mt-2 list-disc list-inside">
                  {cheatingIndicators.map((indicator, index) => (
                    <li key={index}>{indicator}</li>
                  ))}
                </ul>
              </AlertDescription>
            </Alert>
          )}

          {/* Question Analysis */}
          <div className="space-y-4">
            <h3 className="font-semibold">Question-by-Question Analysis</h3>
            {session.questions.map((question: any, index: number) => (
              <div key={index} className="border rounded-lg p-4">
                <div className="flex items-start justify-between mb-2">
                  <h4 className="font-medium">Question {index + 1}</h4>
                  <Badge variant={analysis[index]?.overall_score > 70 ? "default" : "secondary"}>
                    {analysis[index]?.overall_score || 0}/100
                  </Badge>
                </div>
                <p className="text-sm text-gray-600 mb-2">{question.question}</p>
                <p className="text-sm mb-2">
                  <strong>Answer:</strong> {answers[index]}
                </p>
                {analysis[index]?.detailed_feedback && (
                  <p className="text-sm text-blue-600">
                    <strong>AI Feedback:</strong> {analysis[index].detailed_feedback}
                  </p>
                )}
              </div>
            ))}
          </div>

          <Button onClick={() => window.location.reload()} className="w-full">
            Start New Interview
          </Button>
        </CardContent>
      </Card>
    )
  }

  const currentQuestion = session.questions[currentQuestionIndex]

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>
            Question {currentQuestionIndex + 1} of {session.questions.length}
          </span>
          <Badge variant="outline">
            {currentQuestion.difficulty} • {currentQuestion.type}
          </Badge>
        </CardTitle>
        <CardDescription>
          {currentQuestion.time_limit_minutes && (
            <span className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              {currentQuestion.time_limit_minutes} minutes
            </span>
          )}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="p-4 bg-gray-50 rounded-lg">
          <p className="font-medium mb-2">{currentQuestion.question}</p>
          {currentQuestion.expected_topics.length > 0 && (
            <div className="text-sm text-gray-600">
              <strong>Topics to cover:</strong> {currentQuestion.expected_topics.join(", ")}
            </div>
          )}
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium">Your Answer</label>
          <textarea
            className="w-full h-32 p-3 border rounded-md resize-none"
            placeholder="Type your answer here..."
            value={currentAnswer}
            onChange={(e) => setCurrentAnswer(e.target.value)}
          />
        </div>

        <div className="flex gap-2">
          <Button onClick={submitAnswer} disabled={loading || !currentAnswer.trim()} className="flex-1">
            {loading ? "Analyzing..." : "Submit Answer"}
          </Button>

          {currentQuestionIndex > 0 && (
            <Button variant="outline" onClick={() => setCurrentQuestionIndex(currentQuestionIndex - 1)}>
              Previous
            </Button>
          )}
        </div>

        {/* Progress */}
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div
            className="bg-blue-600 h-2 rounded-full transition-all"
            style={{ width: `${((currentQuestionIndex + 1) / session.questions.length) * 100}%` }}
          />
        </div>
      </CardContent>
    </Card>
  )
}
