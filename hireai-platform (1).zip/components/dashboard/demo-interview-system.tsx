"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { MessageSquare, Clock, AlertTriangle, CheckCircle, Brain } from "lucide-react"

export default function DemoInterviewSystem() {
  const [session, setSession] = useState<any>(null)
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [answers, setAnswers] = useState<string[]>([])
  const [currentAnswer, setCurrentAnswer] = useState("")
  const [analysis, setAnalysis] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [sessionComplete, setSessionComplete] = useState(false)

  // Mock interview questions for demo
  const mockQuestions = {
    pre_screening: [
      {
        id: "1",
        question: "Tell me about your experience with AI and machine learning technologies.",
        type: "behavioral",
        difficulty: "easy",
        expected_topics: ["AI", "Machine Learning", "Experience"],
        evaluation_criteria: ["Clarity", "Relevance", "Depth"],
        time_limit_minutes: 5,
      },
      {
        id: "2",
        question: "Why are you interested in this AI Engineer position?",
        type: "behavioral",
        difficulty: "easy",
        expected_topics: ["Motivation", "Career Goals", "Company Interest"],
        evaluation_criteria: ["Enthusiasm", "Alignment", "Research"],
        time_limit_minutes: 3,
      },
    ],
    technical: [
      {
        id: "1",
        question: "Explain how you would implement a recommendation system using machine learning.",
        type: "technical",
        difficulty: "medium",
        expected_topics: ["Collaborative Filtering", "Content-based", "ML Algorithms"],
        evaluation_criteria: ["Technical Accuracy", "Implementation Details", "Scalability"],
        time_limit_minutes: 10,
      },
      {
        id: "2",
        question: "How would you handle overfitting in a deep learning model?",
        type: "technical",
        difficulty: "medium",
        expected_topics: ["Regularization", "Dropout", "Cross-validation"],
        evaluation_criteria: ["Understanding", "Practical Solutions", "Best Practices"],
        time_limit_minutes: 8,
      },
    ],
    behavioral: [
      {
        id: "1",
        question: "Describe a challenging project you worked on and how you overcame obstacles.",
        type: "behavioral",
        difficulty: "medium",
        expected_topics: ["Problem Solving", "Teamwork", "Resilience"],
        evaluation_criteria: ["STAR Method", "Learning", "Impact"],
        time_limit_minutes: 7,
      },
      {
        id: "2",
        question: "How do you stay updated with the latest developments in AI and technology?",
        type: "behavioral",
        difficulty: "easy",
        expected_topics: ["Continuous Learning", "Resources", "Community"],
        evaluation_criteria: ["Proactivity", "Specific Examples", "Passion"],
        time_limit_minutes: 5,
      },
    ],
  }

  const startInterview = async (sessionType: "pre_screening" | "technical" | "behavioral") => {
    setLoading(true)

    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const questions = mockQuestions[sessionType]
    setSession({
      id: "demo-session",
      questions,
      session_type: sessionType,
    })
    setAnswers(new Array(questions.length).fill(""))
    setLoading(false)
  }

  const submitAnswer = async () => {
    if (!currentAnswer.trim() || !session) return

    setLoading(true)

    // Simulate AI analysis delay
    await new Promise((resolve) => setTimeout(resolve, 2000))

    // Mock AI analysis
    const mockAnalysis = {
      overall_score: Math.floor(Math.random() * 30) + 70, // 70-100
      technical_competency: Math.floor(Math.random() * 25) + 75,
      communication_skills: Math.floor(Math.random() * 20) + 80,
      problem_solving: Math.floor(Math.random() * 30) + 70,
      cultural_fit: Math.floor(Math.random() * 25) + 75,
      cheating_probability: Math.floor(Math.random() * 15), // 0-15%
      cheating_indicators: Math.random() > 0.8 ? ["Response seems overly perfect", "Unusual technical depth"] : [],
      strengths: ["Clear communication", "Good technical understanding", "Relevant experience"],
      areas_for_improvement: ["Could provide more specific examples", "Consider elaborating on implementation details"],
      detailed_feedback:
        "Good response showing understanding of the topic. The candidate demonstrates relevant experience and clear thinking.",
      recommendation: "hire",
      next_steps: ["Technical deep-dive interview", "Team culture fit assessment"],
    }

    const newAnswers = [...answers]
    newAnswers[currentQuestionIndex] = currentAnswer
    setAnswers(newAnswers)

    const newAnalysis = [...analysis]
    newAnalysis[currentQuestionIndex] = mockAnalysis
    setAnalysis(newAnalysis)

    setCurrentAnswer("")
    setLoading(false)

    if (currentQuestionIndex < session.questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1)
    } else {
      setSessionComplete(true)
    }
  }

  const getOverallScore = () => {
    if (analysis.length === 0) return 0
    const totalScore = analysis.reduce((sum, a) => sum + (a?.overall_score || 0), 0)
    return Math.round(totalScore / analysis.length)
  }

  const getCheatingIndicators = () => {
    return analysis.flatMap((a) => a?.cheating_indicators || [])
  }

  if (!session) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5" />
            AI Interview System (Demo)
          </CardTitle>
          <CardDescription>
            Experience our AI-powered interview system with adaptive questions and real-time analysis
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert>
            <Brain className="h-4 w-4" />
            <AlertDescription>
              <strong>Demo Mode:</strong> This is a demonstration of our AI interview system. In production, questions
              are dynamically generated based on the candidate's profile and job requirements.
            </AlertDescription>
          </Alert>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button
              onClick={() => startInterview("pre_screening")}
              disabled={loading}
              className="h-20 flex flex-col items-center justify-center"
            >
              <MessageSquare className="h-6 w-6 mb-2" />
              Pre-screening
              <span className="text-xs opacity-75">Basic fit assessment</span>
            </Button>

            <Button
              onClick={() => startInterview("technical")}
              disabled={loading}
              variant="outline"
              className="h-20 flex flex-col items-center justify-center"
            >
              <Brain className="h-6 w-6 mb-2" />
              Technical
              <span className="text-xs opacity-75">Skills evaluation</span>
            </Button>

            <Button
              onClick={() => startInterview("behavioral")}
              disabled={loading}
              variant="outline"
              className="h-20 flex flex-col items-center justify-center"
            >
              <CheckCircle className="h-6 w-6 mb-2" />
              Behavioral
              <span className="text-xs opacity-75">Culture fit assessment</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (sessionComplete) {
    const overallScore = getOverallScore()
    const cheatingIndicators = getCheatingIndicators()

    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-green-600" />
            Interview Complete - AI Analysis Results
          </CardTitle>
          <CardDescription>Comprehensive AI-powered evaluation and scoring</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Overall Score */}
          <div className="text-center">
            <div className="text-4xl font-bold text-blue-600 mb-2">{overallScore}/100</div>
            <p className="text-gray-600">Overall Interview Score</p>
          </div>

          {/* Cheating Detection */}
          {cheatingIndicators.length > 0 && (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                <strong>AI Cheating Detection - Potential Issues:</strong>
                <ul className="mt-2 list-disc list-inside">
                  {cheatingIndicators.map((indicator, index) => (
                    <li key={index}>{indicator}</li>
                  ))}
                </ul>
              </AlertDescription>
            </Alert>
          )}

          {/* Question Analysis */}
          <div className="space-y-4">
            <h3 className="font-semibold">AI Question-by-Question Analysis</h3>
            {session.questions.map((question: any, index: number) => (
              <div key={index} className="border rounded-lg p-4">
                <div className="flex items-start justify-between mb-2">
                  <h4 className="font-medium">Question {index + 1}</h4>
                  <Badge variant={analysis[index]?.overall_score > 70 ? "default" : "secondary"}>
                    {analysis[index]?.overall_score || 0}/100
                  </Badge>
                </div>
                <p className="text-sm text-gray-600 mb-2">{question.question}</p>
                <p className="text-sm mb-2">
                  <strong>Your Answer:</strong> {answers[index]}
                </p>
                {analysis[index]?.detailed_feedback && (
                  <p className="text-sm text-blue-600">
                    <strong>AI Feedback:</strong> {analysis[index].detailed_feedback}
                  </p>
                )}
                {analysis[index]?.strengths && (
                  <div className="mt-2">
                    <p className="text-sm font-medium text-green-600">Strengths:</p>
                    <ul className="text-sm text-green-600 list-disc list-inside">
                      {analysis[index].strengths.map((strength: string, i: number) => (
                        <li key={i}>{strength}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="bg-blue-50 p-4 rounded-lg">
            <h4 className="font-medium text-blue-800 mb-2">AI Recommendation</h4>
            <p className="text-blue-700">
              Based on the comprehensive analysis, this candidate shows strong potential with good technical
              understanding and clear communication skills.
            </p>
          </div>

          <Button onClick={() => window.location.reload()} className="w-full">
            Start New Interview Session
          </Button>
        </CardContent>
      </Card>
    )
  }

  const currentQuestion = session.questions[currentQuestionIndex]

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>
            Question {currentQuestionIndex + 1} of {session.questions.length}
          </span>
          <Badge variant="outline">
            {currentQuestion.difficulty} • {currentQuestion.type}
          </Badge>
        </CardTitle>
        <CardDescription>
          {currentQuestion.time_limit_minutes && (
            <span className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              {currentQuestion.time_limit_minutes} minutes recommended
            </span>
          )}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="p-4 bg-gray-50 rounded-lg">
          <p className="font-medium mb-2">{currentQuestion.question}</p>
          {currentQuestion.expected_topics.length > 0 && (
            <div className="text-sm text-gray-600">
              <strong>AI expects you to cover:</strong> {currentQuestion.expected_topics.join(", ")}
            </div>
          )}
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium">Your Answer</label>
          <textarea
            className="w-full h-32 p-3 border rounded-md resize-none"
            placeholder="Type your answer here... The AI will analyze your response for technical accuracy, communication skills, and potential cheating indicators."
            value={currentAnswer}
            onChange={(e) => setCurrentAnswer(e.target.value)}
          />
        </div>

        <div className="flex gap-2">
          <Button onClick={submitAnswer} disabled={loading || !currentAnswer.trim()} className="flex-1">
            {loading ? "AI Analyzing Response..." : "Submit for AI Analysis"}
          </Button>

          {currentQuestionIndex > 0 && (
            <Button variant="outline" onClick={() => setCurrentQuestionIndex(currentQuestionIndex - 1)}>
              Previous
            </Button>
          )}
        </div>

        {/* Progress */}
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div
            className="bg-blue-600 h-2 rounded-full transition-all"
            style={{ width: `${((currentQuestionIndex + 1) / session.questions.length) * 100}%` }}
          />
        </div>
      </CardContent>
    </Card>
  )
}
