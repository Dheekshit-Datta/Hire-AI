"use server"

import { createClient } from "@/lib/supabase/server"
import { searchLinkedInProfiles } from "@/lib/services/real-linkedin-api"
import type { LinkedInProfile } from "@/lib/services/real-linkedin-api"
import {
  extractSkillsFromQuery,
  extractLocationFromQuery,
  extractExperienceFromQuery,
  extractCompanyFromQuery,
  extractJobTitleFromQuery,
  extractIndustryFromQuery,
} from "@/lib/query-parser"

export async function performLinkedInSearch(searchParams: {
  query: string
  location?: string
  experience?: string
  skills?: string[]
  company?: string
  industry?: string
  jobTitle?: string
}): Promise<{
  profiles: LinkedInProfile[]
  searchTime: number
  totalResults: number
}> {
  const startTime = Date.now()

  try {
    // Parse the query if not already provided in searchParams
    const parsedParams = {
      ...searchParams,
      location: searchParams.location || extractLocationFromQuery(searchParams.query),
      experience: searchParams.experience || extractExperienceFromQuery(searchParams.query),
      skills: searchParams.skills || extractSkillsFromQuery(searchParams.query),
      company: searchParams.company || extractCompanyFromQuery(searchParams.query),
      industry: searchParams.industry || extractIndustryFromQuery(searchParams.query),
      jobTitle: searchParams.jobTitle || extractJobTitleFromQuery(searchParams.query),
    }

    // LinkedIn API search (with fallback handling built-in)
    const profiles = await searchLinkedInProfiles(parsedParams)

    const searchTime = Date.now() - startTime

    // Log the search for analytics
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (user) {
      try {
        await supabase.from("search_queries").insert({
          recruiter_id: user.id,
          query_text: searchParams.query,
          parsed_criteria: parsedParams,
          results_count: profiles.length,
          execution_time_ms: searchTime,
        })

        // Log AI decision for audit trail
        await supabase.from("ai_decision_logs").insert({
          action_type: "linkedin_search",
          entity_type: "search_query",
          entity_id: user.id,
          input_data: parsedParams,
          ai_response: {
            profiles_found: profiles.length,
            search_time: searchTime,
            source: "linkedin_api_with_fallback",
            top_profiles: profiles.slice(0, 3).map((p) => ({
              name: p.name,
              company: p.company,
              location: p.location,
            })),
          },
          confidence_score: profiles.length > 0 ? 95 : 0,
          model_used: "linkedin-api-v2",
          processing_time_ms: searchTime,
        })
      } catch (logError) {
        console.warn("Failed to log search query:", logError)
        // Continue execution even if logging fails
      }
    }

    return {
      profiles,
      searchTime,
      totalResults: profiles.length,
    }
  } catch (error) {
    console.error("LinkedIn search failed:", error)

    // Return empty results rather than throwing
    // The searchLinkedInProfiles function already handles fallbacks
    return {
      profiles: [],
      searchTime: Date.now() - startTime,
      totalResults: 0,
    }
  }
}

export async function addLinkedInCandidateToDatabase(profileData: any): Promise<any> {
  const supabase = await createClient()

  try {
    const { data: candidate, error } = await supabase.from("candidates").insert(profileData).select().single()

    if (error) {
      throw new Error("Failed to add LinkedIn candidate to database")
    }

    // Log the addition
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (user) {
      await supabase.from("ai_decision_logs").insert({
        action_type: "linkedin_candidate_import",
        entity_type: "candidate",
        entity_id: candidate.id,
        input_data: { linkedin_profile: profileData.full_name },
        ai_response: { candidate_id: candidate.id },
        confidence_score: 100,
        model_used: "linkedin-import",
        processing_time_ms: 0,
      })
    }

    return candidate
  } catch (error) {
    console.error("Failed to add LinkedIn candidate:", error)
    throw new Error("Failed to add candidate to database")
  }
}
