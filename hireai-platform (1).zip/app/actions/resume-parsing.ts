"use server"

import { createClient } from "@/lib/supabase/server"
import { parseResumeWithAI } from "@/lib/ai/advanced-ai"
import type { Candidate } from "@/lib/types"

export async function parseAndAddCandidate(resumeText: string): Promise<Candidate> {
  const supabase = await createClient()

  try {
    // Parse resume with AI
    const parsedData = await parseResumeWithAI(resumeText)

    // Extract email from resume text (simple regex)
    const emailMatch = resumeText.match(/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/)
    const email = emailMatch ? emailMatch[0] : `candidate_${Date.now()}@example.com`

    // Create candidate object
    const candidateData = {
      email,
      full_name: parsedData.current_position
        ? resumeText.split("\n")[0].trim()
        : // First line is usually the name
          `Candidate ${Date.now()}`,
      resume_text: resumeText,
      skills: parsedData.skills || [],
      experience_years: parsedData.experience_years || 0,
      current_position: parsedData.current_position,
      current_company: parsedData.current_company,
      education: parsedData.education || [],
      certifications: parsedData.certifications || [],
      languages: parsedData.languages || ["English"],
      availability_status: "available" as const,
    }

    // Insert candidate into database
    const { data: candidate, error } = await supabase.from("candidates").insert(candidateData).select().single()

    if (error) {
      throw new Error("Failed to add candidate to database")
    }

    // Log AI decision
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (user) {
      await supabase.from("ai_decision_logs").insert({
        action_type: "resume_parsing",
        entity_type: "candidate",
        entity_id: candidate.id,
        input_data: { resume_length: resumeText.length },
        ai_response: parsedData,
        confidence_score: 85, // Assume good confidence for parsing
        model_used: "gpt-4o",
        processing_time_ms: 0,
      })
    }

    return candidate
  } catch (error) {
    console.error("Resume parsing failed:", error)
    throw new Error("Failed to parse resume")
  }
}
