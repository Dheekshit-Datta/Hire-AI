"use server"

import { createClient } from "@/lib/supabase/server"
import { analyzeInterviewResponseAdvanced } from "@/lib/ai/advanced-ai"

export async function analyzeInterviewResponse(
  question: string,
  answer: string,
  expectedTopics: string[],
  evaluationCriteria: string[],
  candidateProfile: any,
): Promise<any> {
  const supabase = await createClient()

  try {
    // Get full candidate profile if only ID provided
    let candidate = candidateProfile
    if (typeof candidateProfile === "string" || candidateProfile.id) {
      const { data, error } = await supabase
        .from("candidates")
        .select("*")
        .eq("id", candidateProfile.id || candidateProfile)
        .single()

      if (!error && data) {
        candidate = data
      }
    }

    // Analyze response with AI
    const analysis = await analyzeInterviewResponseAdvanced(
      question,
      answer,
      expectedTopics,
      evaluationCriteria,
      candidate,
    )

    // Log AI decision
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (user) {
      await supabase.from("ai_decision_logs").insert({
        action_type: "interview_analysis",
        entity_type: "interview_response",
        entity_id: candidate.id,
        input_data: { question, answer, expected_topics: expectedTopics },
        ai_response: analysis,
        confidence_score: analysis.overall_score,
        model_used: "gpt-4o",
        processing_time_ms: 0,
      })
    }

    return analysis
  } catch (error) {
    console.error("Interview analysis failed:", error)
    throw new Error("Failed to analyze interview response")
  }
}
