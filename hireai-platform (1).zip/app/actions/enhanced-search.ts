"use server"

import { createClient } from "@/lib/supabase/server"
import { parseSearchQueryWithFallback, scoreCandidateWithFallback } from "@/lib/ai/enhanced-ai"
import { searchLinkedInProfiles, convertLinkedInProfileToCandidate } from "@/lib/services/linkedin-scraper"
import type { CandidateScore, Candidate } from "@/lib/types"

export async function searchCandidatesWithLinkedIn(query: string): Promise<{
  databaseResults: CandidateScore[]
  linkedinResults: CandidateScore[]
  totalResults: number
  searchTime: number
}> {
  const supabase = await createClient()
  const startTime = Date.now()

  try {
    // Parse the natural language query with AI (with fallback)
    const parsedCriteria = await parseSearchQueryWithFallback(query)

    // Search existing database
    let candidatesQuery = supabase.from("candidates").select("*")

    // Apply location filters
    if (parsedCriteria.location) {
      candidatesQuery = candidatesQuery.or(
        `country.ilike.%${parsedCriteria.location}%,city.ilike.%${parsedCriteria.location}%,location.ilike.%${parsedCriteria.location}%`,
      )
    }

    // Apply experience filters
    if (parsedCriteria.experience_years) {
      candidatesQuery = candidatesQuery.gte("experience_years", parsedCriteria.experience_years)
    }

    // Apply availability filter
    candidatesQuery = candidatesQuery.neq("availability_status", "not_available")

    const { data: existingCandidates, error } = await candidatesQuery

    if (error) {
      console.warn("Database search failed:", error)
    }

    // Search LinkedIn profiles
    const linkedinProfiles = await searchLinkedInProfiles({
      query,
      location: parsedCriteria.location,
      experience: parsedCriteria.experience_years?.toString(),
      skills: parsedCriteria.skills,
    })

    // Score existing candidates
    const databaseResults: CandidateScore[] = []
    if (existingCandidates) {
      for (const candidate of existingCandidates) {
        try {
          const scoring = await scoreCandidateWithFallback(
            candidate,
            { query, parsed_criteria: parsedCriteria },
            parsedCriteria,
          )

          if (scoring.overall_score > 30) {
            databaseResults.push({
              id: `${candidate.id}-search-${Date.now()}`,
              candidate_id: candidate.id,
              job_posting_id: "",
              overall_score: scoring.overall_score,
              skill_match_score: scoring.skill_match_score,
              experience_score: scoring.experience_score,
              location_score: scoring.location_score,
              ai_reasoning: scoring.reasoning,
              created_at: new Date().toISOString(),
              candidate: candidate,
            })
          }
        } catch (error) {
          console.warn(`Failed to score candidate ${candidate.id}:`, error)
        }
      }
    }

    // Score LinkedIn profiles
    const linkedinResults: CandidateScore[] = []
    for (const profile of linkedinProfiles) {
      try {
        const candidateData = convertLinkedInProfileToCandidate(profile)
        const scoring = await scoreCandidateWithFallback(
          candidateData,
          { query, parsed_criteria: parsedCriteria },
          parsedCriteria,
        )

        linkedinResults.push({
          id: `linkedin-${Date.now()}-${Math.random()}`,
          candidate_id: `linkedin-${profile.name.replace(/\s+/g, "-").toLowerCase()}`,
          job_posting_id: "",
          overall_score: scoring.overall_score,
          skill_match_score: scoring.skill_match_score,
          experience_score: scoring.experience_score,
          location_score: scoring.location_score,
          ai_reasoning: `LinkedIn Profile: ${scoring.reasoning}`,
          created_at: new Date().toISOString(),
          candidate: {
            ...candidateData,
            id: `linkedin-${profile.name.replace(/\s+/g, "-").toLowerCase()}`,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          } as Candidate,
        })
      } catch (error) {
        console.warn(`Failed to score LinkedIn profile ${profile.name}:`, error)
      }
    }

    // Sort results by score
    databaseResults.sort((a, b) => b.overall_score - a.overall_score)
    linkedinResults.sort((a, b) => b.overall_score - a.overall_score)

    // Log the search query
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (user) {
      await supabase.from("search_queries").insert({
        recruiter_id: user.id,
        query_text: query,
        parsed_criteria: parsedCriteria,
        results_count: databaseResults.length + linkedinResults.length,
        execution_time_ms: Date.now() - startTime,
      })

      // Log AI decision for audit trail
      await supabase.from("ai_decision_logs").insert({
        action_type: "candidate_search_with_linkedin",
        entity_type: "search_query",
        entity_id: user.id,
        input_data: { query, parsed_criteria: parsedCriteria },
        ai_response: {
          database_results: databaseResults.length,
          linkedin_results: linkedinResults.length,
          top_scores: [...databaseResults, ...linkedinResults]
            .sort((a, b) => b.overall_score - a.overall_score)
            .slice(0, 5)
            .map((c) => c.overall_score),
        },
        confidence_score:
          databaseResults.length + linkedinResults.length > 0
            ? Math.max(...databaseResults.concat(linkedinResults).map((c) => c.overall_score))
            : 0,
        model_used: "gpt-4o-with-fallback",
        processing_time_ms: Date.now() - startTime,
      })
    }

    return {
      databaseResults: databaseResults.slice(0, 10),
      linkedinResults: linkedinResults.slice(0, 10),
      totalResults: databaseResults.length + linkedinResults.length,
      searchTime: Date.now() - startTime,
    }
  } catch (error) {
    console.error("Enhanced search failed:", error)
    throw new Error("Search failed. Please try again.")
  }
}

export async function addLinkedInCandidateToDatabase(candidateData: Partial<Candidate>): Promise<Candidate> {
  const supabase = await createClient()

  try {
    const { data: candidate, error } = await supabase.from("candidates").insert(candidateData).select().single()

    if (error) {
      throw new Error("Failed to add LinkedIn candidate to database")
    }

    return candidate
  } catch (error) {
    console.error("Failed to add LinkedIn candidate:", error)
    throw new Error("Failed to add candidate to database")
  }
}
