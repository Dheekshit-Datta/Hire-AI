"use server"

import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"

export async function setupNewUser() {
  const supabase = await createClient()

  try {
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      redirect("/auth/login")
    }

    // Check if user profile exists
    const { data: existingProfile } = await supabase.from("users").select("*").eq("id", user.id).single()

    if (!existingProfile) {
      // Create user profile with fresh data
      const { error: profileError } = await supabase.from("users").insert({
        id: user.id,
        email: user.email!,
        full_name: user.user_metadata?.full_name || user.email!.split("@")[0],
        company_name: user.user_metadata?.company_name || "My Company",
        role: "recruiter",
        created_at: new Date().toISOString(),
        // Ensure fresh start - no pre-populated data
        onboarding_completed: false,
        preferences: {
          email_notifications: true,
          dashboard_layout: "default",
          search_filters: {},
        },
      })

      if (profileError) {
        console.error("Error creating user profile:", profileError)
      }

      // Initialize empty workspace for new user
      await initializeEmptyWorkspace(user.id)
    }

    return { success: true, user }
  } catch (error) {
    console.error("Setup error:", error)
    return { success: false, error: "Failed to setup user" }
  }
}

async function initializeEmptyWorkspace(userId: string) {
  const supabase = await createClient()

  try {
    // Create empty workspace structure for new user
    // This ensures they start with a clean slate

    // Initialize user settings
    await supabase.from("user_settings").upsert({
      user_id: userId,
      theme: "light",
      notifications_enabled: true,
      email_notifications: true,
      search_preferences: {},
      dashboard_layout: "default",
    })

    // Log the workspace initialization
    await supabase.from("activity_logs").insert({
      user_id: userId,
      action: "workspace_initialized",
      details: { type: "fresh_start", timestamp: new Date().toISOString() },
    })
  } catch (error) {
    console.warn("Failed to initialize workspace:", error)
    // Don't throw error - user can still use the platform
  }
}

export async function getUserStats(userId: string) {
  const supabase = await createClient()

  try {
    // Get user's actual data counts (will be 0 for new users)
    const [candidatesResult, jobsResult, interviewsResult] = await Promise.all([
      supabase.from("candidates").select("id", { count: "exact" }).eq("recruiter_id", userId),
      supabase.from("job_postings").select("id", { count: "exact" }).eq("recruiter_id", userId),
      supabase.from("interview_sessions").select("id", { count: "exact" }).eq("recruiter_id", userId),
    ])

    return {
      totalCandidates: candidatesResult.count || 0,
      activeJobs: jobsResult.count || 0,
      pendingInterviews: interviewsResult.count || 0,
      newApplications: 0, // Fresh start for new users
      recentSearches: [],
    }
  } catch (error) {
    console.error("Error getting user stats:", error)
    // Return fresh workspace stats for new users
    return {
      totalCandidates: 0,
      activeJobs: 0,
      pendingInterviews: 0,
      newApplications: 0,
      recentSearches: [],
    }
  }
}

export async function checkUserDataIsolation(userId: string) {
  const supabase = await createClient()

  try {
    // Verify user only sees their own data
    const [userCandidates, userJobs] = await Promise.all([
      supabase.from("candidates").select("id").eq("recruiter_id", userId),
      supabase.from("job_postings").select("id").eq("recruiter_id", userId),
    ])

    return {
      hasIsolatedData: true,
      candidateCount: userCandidates.data?.length || 0,
      jobCount: userJobs.data?.length || 0,
    }
  } catch (error) {
    console.error("Error checking data isolation:", error)
    return {
      hasIsolatedData: false,
      candidateCount: 0,
      jobCount: 0,
    }
  }
}
