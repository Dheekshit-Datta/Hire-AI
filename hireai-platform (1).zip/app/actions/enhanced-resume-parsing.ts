"use server"

import { createClient } from "@/lib/supabase/server"
import { extractSkillsWithFallback } from "@/lib/ai/enhanced-ai"
import type { Candidate } from "@/lib/types"

export async function parseAndAddCandidateWithFallback(resumeText: string): Promise<Candidate> {
  const supabase = await createClient()

  try {
    // Extract skills with AI (with fallback)
    const extractedSkills = await extractSkillsWithFallback(resumeText)

    // Extract basic information using simple parsing
    const lines = resumeText.split("\n").filter((line) => line.trim())

    // Extract email
    const emailMatch = resumeText.match(/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/)
    const email = emailMatch ? emailMatch[0] : `candidate_${Date.now()}@example.com`

    // Extract name (usually first line or line with common name patterns)
    let fullName = lines[0]?.trim() || `Candidate ${Date.now()}`

    // Look for name patterns
    const namePatterns = [/^([A-Z][a-z]+ [A-Z][a-z]+)/, /Name:?\s*([A-Z][a-z]+ [A-Z][a-z]+)/i]

    for (const pattern of namePatterns) {
      const match = resumeText.match(pattern)
      if (match) {
        fullName = match[1]
        break
      }
    }

    // Extract experience years
    const expMatches = resumeText.match(/(\d+)\+?\s*years?\s*(of\s*)?(experience|exp)/gi)
    let experienceYears = 0
    if (expMatches) {
      const years = expMatches.map((match) => Number.parseInt(match.match(/\d+/)?.[0] || "0"))
      experienceYears = Math.max(...years)
    }

    // Extract current position and company
    const positionMatches = resumeText.match(
      /(Senior|Junior|Lead|Principal)?\s*(Software Engineer|Developer|Engineer|Manager|Analyst|Scientist|Architect)/gi,
    )
    const currentPosition = positionMatches?.[0] || "Professional"

    const companyMatches = resumeText.match(/(?:at|@)\s+([A-Z][a-zA-Z\s&.]+(?:Inc|LLC|Corp|Ltd|Company)?)/g)
    const currentCompany = companyMatches?.[0]?.replace(/^(?:at|@)\s+/, "") || undefined

    // Extract location
    const locationMatches = resumeText.match(/(?:Location|Address|Based in):?\s*([A-Z][a-zA-Z\s,]+)/i)
    const location = locationMatches?.[1] || undefined

    // Create candidate object
    const candidateData = {
      email,
      full_name: fullName,
      resume_text: resumeText,
      skills: extractedSkills,
      experience_years: experienceYears,
      current_position: currentPosition,
      current_company: currentCompany,
      location,
      education: [],
      certifications: [],
      languages: ["English"],
      availability_status: "available" as const,
    }

    // Insert candidate into database
    const { data: candidate, error } = await supabase.from("candidates").insert(candidateData).select().single()

    if (error) {
      throw new Error("Failed to add candidate to database")
    }

    // Log AI decision
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (user) {
      await supabase.from("ai_decision_logs").insert({
        action_type: "resume_parsing_enhanced",
        entity_type: "candidate",
        entity_id: candidate.id,
        input_data: { resume_length: resumeText.length },
        ai_response: { extracted_skills: extractedSkills, experience_years: experienceYears },
        confidence_score: 85,
        model_used: "gpt-4o-with-fallback",
        processing_time_ms: 0,
      })
    }

    return candidate
  } catch (error) {
    console.error("Enhanced resume parsing failed:", error)
    throw new Error("Failed to parse resume")
  }
}
