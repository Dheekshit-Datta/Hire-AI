"use server"

import { createClient } from "@/lib/supabase/server"
import type { Candidate } from "@/lib/types"

// Mock candidates data for fallback
const mockCandidatesData: Candidate[] = [
  {
    id: "1",
    full_name: "Sarah Chen",
    email: "sarah.chen@email.com",
    phone: "+1 (555) 123-4567",
    current_position: "Senior AI Engineer",
    current_company: "TechCorp",
    location: "San Francisco, CA",
    country: "USA",
    city: "San Francisco",
    experience_years: 6,
    skills: ["Python", "TensorFlow", "React", "AWS", "Machine Learning", "Docker"],
    availability_status: "available",
    resume_url: null,
    resume_text: null,
    education: [
      {
        degree: "MS Computer Science",
        school: "Stanford University",
        year: "2018",
        field: "Artificial Intelligence",
      },
    ],
    certifications: [
      {
        name: "AWS Certified Solutions Architect",
        issuer: "Amazon Web Services",
        year: "2022",
      },
    ],
    languages: ["English", "Mandarin"],
    salary_expectation: 180000,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: "2",
    full_name: "Marcus Johnson",
    email: "marcus.j@email.com",
    phone: "+1 (555) 234-5678",
    current_position: "Full Stack Developer",
    current_company: "StartupXYZ",
    location: "Austin, TX",
    country: "USA",
    city: "Austin",
    experience_years: 4,
    skills: ["JavaScript", "React", "Node.js", "Python", "PostgreSQL", "AWS"],
    availability_status: "available",
    resume_url: null,
    resume_text: null,
    education: [
      {
        degree: "BS Computer Science",
        school: "UT Austin",
        year: "2020",
        field: "Software Engineering",
      },
    ],
    certifications: [],
    languages: ["English", "Spanish"],
    salary_expectation: 120000,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: "3",
    full_name: "Elena Rodriguez",
    email: "elena.r@email.com",
    phone: "+49 123 456 7890",
    current_position: "Data Scientist",
    current_company: "DataTech Europe",
    location: "Berlin, Germany",
    country: "Germany",
    city: "Berlin",
    experience_years: 5,
    skills: ["Python", "R", "TensorFlow", "SQL", "Tableau", "Machine Learning"],
    availability_status: "available",
    resume_url: null,
    resume_text: null,
    education: [
      {
        degree: "PhD Data Science",
        school: "Technical University of Berlin",
        year: "2019",
        field: "Machine Learning",
      },
    ],
    certifications: [
      {
        name: "Google Cloud Professional Data Engineer",
        issuer: "Google Cloud",
        year: "2021",
      },
    ],
    languages: ["English", "Spanish", "German"],
    salary_expectation: 95000,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: "4",
    full_name: "David Kim",
    email: "david.kim@email.com",
    phone: "+1 (555) 345-6789",
    current_position: "DevOps Engineer",
    current_company: "CloudTech Solutions",
    location: "Seattle, WA",
    country: "USA",
    city: "Seattle",
    experience_years: 7,
    skills: ["Kubernetes", "Docker", "AWS", "Terraform", "Python", "Jenkins"],
    availability_status: "available",
    resume_url: null,
    resume_text: null,
    education: [
      {
        degree: "BS Software Engineering",
        school: "University of Washington",
        year: "2017",
        field: "Computer Systems",
      },
    ],
    certifications: [
      {
        name: "Certified Kubernetes Administrator",
        issuer: "Cloud Native Computing Foundation",
        year: "2022",
      },
    ],
    languages: ["English", "Korean"],
    salary_expectation: 150000,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: "5",
    full_name: "Priya Patel",
    email: "priya.patel@email.com",
    phone: "+44 20 1234 5678",
    current_position: "Product Manager",
    current_company: "InnovateLab",
    location: "London, UK",
    country: "UK",
    city: "London",
    experience_years: 8,
    skills: ["Product Strategy", "Agile", "Data Analysis", "User Research", "SQL", "Figma"],
    availability_status: "available",
    resume_url: null,
    resume_text: null,
    education: [
      {
        degree: "MBA",
        school: "London Business School",
        year: "2016",
        field: "Business Administration",
      },
      {
        degree: "BS Engineering",
        school: "Imperial College London",
        year: "2014",
        field: "Industrial Engineering",
      },
    ],
    certifications: [
      {
        name: "Certified Scrum Product Owner",
        issuer: "Scrum Alliance",
        year: "2020",
      },
    ],
    languages: ["English", "Hindi", "Gujarati"],
    salary_expectation: 110000,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
]

export async function getCandidates(): Promise<Candidate[]> {
  try {
    const supabase = await createClient()

    // Check if we have valid Supabase environment variables
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
    const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

    if (!supabaseUrl || !supabaseAnonKey) {
      console.log("Using demo mode - returning mock candidates")
      return mockCandidatesData
    }

    const { data, error } = await supabase.from("candidates").select("*").order("created_at", { ascending: false })

    if (error) {
      console.log("Database error, falling back to mock data:", error.message)
      return mockCandidatesData
    }

    // If no data from database, return mock data
    if (!data || data.length === 0) {
      console.log("No candidates in database, returning mock data")
      return mockCandidatesData
    }

    return data
  } catch (error) {
    console.log("Connection error, using mock data:", error)
    return mockCandidatesData
  }
}

export async function addCandidate(candidateData: Partial<Candidate>): Promise<Candidate | null> {
  try {
    const supabase = await createClient()

    // Check if we have valid Supabase environment variables
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
    const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

    if (!supabaseUrl || !supabaseAnonKey) {
      console.log("Demo mode - cannot add candidates")
      return null
    }

    const { data, error } = await supabase.from("candidates").insert(candidateData).select().single()

    if (error) {
      console.error("Failed to add candidate:", error)
      return null
    }

    return data
  } catch (error) {
    console.error("Database connection error:", error)
    return null
  }
}
