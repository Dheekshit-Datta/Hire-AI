import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Brain, CheckCircle, Calendar, Mail, Slack, Chrome } from "lucide-react"
import Link from "next/link"

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-blue-50 relative overflow-hidden">
      {/* Floating Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-2 h-2 bg-blue-400 rounded-full opacity-60 animate-pulse"></div>
        <div className="absolute top-40 right-20 w-1 h-1 bg-purple-400 rounded-full opacity-40"></div>
        <div className="absolute bottom-40 left-20 w-3 h-3 bg-green-400 rounded-full opacity-50"></div>
        <div className="absolute bottom-20 right-40 w-2 h-2 bg-orange-400 rounded-full opacity-60"></div>
      </div>

      {/* Header */}
      <header className="relative z-50 bg-white/80 backdrop-blur-md border-b border-gray-100">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
              <div className="w-2 h-2 bg-purple-600 rounded-full"></div>
            </div>
            <span className="text-xl font-bold text-gray-900">HireAI</span>
          </div>

          <nav className="hidden md:flex items-center gap-8">
            <Link href="#features" className="text-gray-600 hover:text-gray-900 font-medium transition-colors">
              Features
            </Link>
            <Link href="#solutions" className="text-gray-600 hover:text-gray-900 font-medium transition-colors">
              Solutions
            </Link>
            <Link href="#resources" className="text-gray-600 hover:text-gray-900 font-medium transition-colors">
              Resources
            </Link>
            <Link href="#pricing" className="text-gray-600 hover:text-gray-900 font-medium transition-colors">
              Pricing
            </Link>
          </nav>

          <div className="flex items-center gap-3">
            <Button variant="ghost" asChild className="text-gray-600 hover:text-gray-900 font-medium">
              <Link href="/auth/login">Sign in</Link>
            </Button>
            <Button asChild className="bg-blue-600 hover:bg-blue-700 shadow-lg hover:shadow-xl transition-all">
              <Link href="/demo">Get demo</Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 px-6">
        <div className="container mx-auto text-center relative z-10">
          {/* Floating Sticky Note */}
          <div className="absolute -top-5 left-10 transform rotate-12 hidden lg:block">
            <div className="w-56 h-40 bg-gradient-to-br from-yellow-200 to-yellow-300 rounded-lg shadow-xl p-4 relative">
              <div className="absolute top-2 left-2 w-4 h-4 bg-red-500 rounded-full shadow-md"></div>
              <div className="mt-6 space-y-2">
                <div className="text-sm text-gray-800 font-handwriting leading-relaxed">
                  Take notes to keep
                  <br />
                  track of crucial details,
                  <br />
                  and accomplish more
                  <br />
                  tasks with ease.
                </div>
              </div>
            </div>
          </div>

          {/* Floating Task Completion */}
          <div className="absolute top-16 left-20 transform -rotate-6 hidden lg:block">
            <div className="w-16 h-16 bg-white rounded-2xl shadow-2xl flex items-center justify-center">
              <CheckCircle className="w-8 h-8 text-blue-600" />
            </div>
          </div>

          {/* Central App Icon */}
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-20 hidden lg:block">
            <div className="w-24 h-24 bg-white rounded-3xl shadow-2xl flex items-center justify-center border border-gray-100">
              <div className="grid grid-cols-2 gap-2">
                <div className="w-5 h-5 bg-blue-600 rounded-lg"></div>
                <div className="w-5 h-5 bg-gray-800 rounded-lg"></div>
                <div className="w-5 h-5 bg-gray-800 rounded-lg"></div>
                <div className="w-5 h-5 bg-gray-800 rounded-lg"></div>
              </div>
            </div>
          </div>

          {/* Floating Reminders Card */}
          <div className="absolute top-10 right-16 transform rotate-3 hidden lg:block">
            <div className="w-64 h-48 bg-white rounded-2xl shadow-2xl p-6 border border-gray-100">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
                  <Calendar className="w-4 h-4 text-gray-600" />
                </div>
                <span className="font-semibold text-gray-900">Reminders</span>
              </div>
              <div className="space-y-3">
                <div className="text-sm font-medium text-gray-900">Today's Meeting</div>
                <div className="text-xs text-gray-500">Sarah Chen - AI Engineer</div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-blue-600 rounded-full"></div>
                  <span className="text-xs text-blue-600 font-medium">10:00 - 11:45</span>
                </div>
              </div>
            </div>
          </div>

          {/* Floating Today's Tasks */}
          <div className="absolute bottom-20 left-16 transform -rotate-2 hidden lg:block">
            <div className="w-72 h-56 bg-white rounded-2xl shadow-2xl p-6 border border-gray-100">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-6 h-6 bg-orange-500 rounded"></div>
                <span className="font-semibold text-gray-900">Today's tasks</span>
              </div>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center">
                    <span className="text-xs font-bold text-orange-600">SC</span>
                  </div>
                  <div className="flex-1">
                    <div className="text-sm font-medium text-gray-900">New ideas for campaign</div>
                    <div className="text-xs text-gray-500">Sep 10</div>
                    <div className="w-full bg-gray-200 rounded-full h-1.5 mt-2">
                      <div className="bg-orange-500 h-1.5 rounded-full" style={{ width: "60%" }}></div>
                    </div>
                  </div>
                  <span className="text-xs text-gray-400">60%</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                    <span className="text-xs font-bold text-green-600">MJ</span>
                  </div>
                  <div className="flex-1">
                    <div className="text-sm font-medium text-gray-900">Design PPT #4</div>
                    <div className="text-xs text-gray-500">Sep 10</div>
                    <div className="w-full bg-gray-200 rounded-full h-1.5 mt-2">
                      <div className="bg-green-500 h-1.5 rounded-full" style={{ width: "75%" }}></div>
                    </div>
                  </div>
                  <span className="text-xs text-gray-400">75%</span>
                </div>
              </div>
            </div>
          </div>

          {/* Floating Integrations */}
          <div className="absolute bottom-16 right-20 transform rotate-1 hidden lg:block">
            <div className="w-64 h-44 bg-white rounded-2xl shadow-2xl p-6 border border-gray-100">
              <div className="text-sm font-semibold text-gray-900 mb-4">100+ Integrations</div>
              <div className="grid grid-cols-3 gap-3">
                <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-red-600 rounded-xl flex items-center justify-center shadow-lg">
                  <Mail className="w-6 h-6 text-white" />
                </div>
                <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                  <Slack className="w-6 h-6 text-white" />
                </div>
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg">
                  <Calendar className="w-6 h-6 text-white" />
                </div>
                <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center shadow-lg">
                  <span className="text-white font-bold text-sm">S</span>
                </div>
                <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl flex items-center justify-center shadow-lg">
                  <span className="text-white font-bold text-sm">H</span>
                </div>
                <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg">
                  <Chrome className="w-6 h-6 text-white" />
                </div>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="max-w-5xl mx-auto pt-32 relative z-30">
            <h1 className="text-7xl font-bold text-gray-900 mb-8 leading-tight tracking-tight">
              Think, plan, and track
              <br />
              <span className="text-gray-400">all in one place</span>
            </h1>
            <p className="text-xl text-gray-600 mb-12 max-w-2xl mx-auto leading-relaxed">
              Efficiently manage your tasks and boost productivity.
            </p>
            <Button
              size="lg"
              className="bg-blue-600 hover:bg-blue-700 text-white px-12 py-6 text-lg font-semibold rounded-xl shadow-xl hover:shadow-2xl transition-all transform hover:scale-105"
            >
              Get free demo
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-32 px-6 bg-gradient-to-b from-white to-gray-50">
        <div className="container mx-auto">
          <div className="text-center mb-20">
            <h2 className="text-5xl font-bold text-gray-900 mb-6">Powerful AI Features</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Transform your hiring process with cutting-edge AI technology
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: Brain,
                title: "AI-Powered Search",
                description: "Search candidates using natural language with advanced AI matching",
                color: "from-blue-500 to-blue-600",
              },
              {
                icon: CheckCircle,
                title: "LinkedIn Integration",
                description: "Scrape and import candidates directly from LinkedIn profiles",
                color: "from-green-500 to-green-600",
              },
              {
                icon: Calendar,
                title: "Smart Interviews",
                description: "AI-generated questions with real-time analysis and scoring",
                color: "from-purple-500 to-purple-600",
              },
            ].map((feature, index) => (
              <Card
                key={index}
                className="group border-0 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 bg-gradient-to-br from-white to-gray-50"
              >
                <CardContent className="p-8">
                  <div
                    className={`w-16 h-16 bg-gradient-to-br ${feature.color} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform shadow-lg`}
                  >
                    <feature.icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold mb-4 text-gray-900">{feature.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32 px-6 bg-gradient-to-br from-blue-600 via-blue-700 to-purple-700 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-purple-500/10 opacity-20"></div>
        <div className="container mx-auto text-center relative z-10">
          <h2 className="text-5xl font-bold text-white mb-6">Ready to Transform Your Hiring?</h2>
          <p className="text-xl text-blue-100 mb-12 max-w-3xl mx-auto leading-relaxed">
            Join thousands of companies using AI to find better candidates faster than ever before
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <Button
              size="lg"
              variant="secondary"
              asChild
              className="px-12 py-6 text-lg font-semibold rounded-xl shadow-xl hover:shadow-2xl transition-all transform hover:scale-105"
            >
              <Link href="/demo">Try Demo</Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent border-2 border-white text-white hover:bg-white hover:text-blue-600 px-12 py-6 text-lg font-semibold rounded-xl shadow-xl hover:shadow-2xl transition-all transform hover:scale-105"
              asChild
            >
              <Link href="/auth/signup">Start Free Trial</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16 px-6">
        <div className="container mx-auto text-center">
          <div className="flex items-center justify-center gap-3 mb-6">
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 bg-blue-600 rounded-full"></div>
              <div className="w-3 h-3 bg-purple-600 rounded-full"></div>
            </div>
            <span className="text-2xl font-bold">HireAI</span>
          </div>
          <p className="text-gray-400 text-lg">© 2024 HireAI. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}
