import DashboardContent from "@/components/dashboard/dashboard-content"

// Demo page that bypasses authentication for testing
export default function DemoPage() {
  const mockUser = {
    id: "demo-user",
    email: "demo@hireai.com",
    full_name: "Demo User",
    company_name: "Demo Company",
    role: "recruiter",
  }

  const mockStats = {
    totalCandidates: 8,
    activeJobs: 3,
    recentSearches: [],
  }

  return <DashboardContent user={mockUser} stats={mockStats} />
}
