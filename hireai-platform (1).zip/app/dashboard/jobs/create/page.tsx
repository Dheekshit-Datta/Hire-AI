"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Plus, X, Briefcase, CheckCircle } from "lucide-react"
import { createClient } from "@/lib/supabase/client"

export default function CreateJobPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState("")
  const [skills, setSkills] = useState<string[]>([])
  const [newSkill, setNewSkill] = useState("")

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    location: "",
    country: "",
    city: "",
    salary_range_min: "",
    salary_range_max: "",
    experience_required: "",
    job_type: "",
    remote_allowed: false,
  })

  const addSkill = () => {
    if (newSkill.trim() && !skills.includes(newSkill.trim())) {
      setSkills([...skills, newSkill.trim()])
      setNewSkill("")
    }
  }

  const removeSkill = (skillToRemove: string) => {
    setSkills(skills.filter((skill) => skill !== skillToRemove))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    try {
      const supabase = createClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      const jobData = {
        title: formData.title,
        description: formData.description,
        location: formData.location || "Remote",
        country: formData.country || "Global",
        city: formData.city || "",
        salary_range_min: formData.salary_range_min ? Number.parseInt(formData.salary_range_min) : null,
        salary_range_max: formData.salary_range_max ? Number.parseInt(formData.salary_range_max) : null,
        experience_required: Number.parseInt(formData.experience_required) || 0,
        job_type: formData.job_type,
        remote_allowed: formData.remote_allowed,
        skills_required: skills,
        requirements: skills,
        status: "active",
        recruiter_id: user?.id || "demo-user",
        created_at: new Date().toISOString(),
      }

      if (user) {
        const { error: insertError } = await supabase.from("job_postings").insert(jobData)
        if (insertError) {
          console.error("Database error:", insertError)
          // Continue to success for demo purposes
        }
      }

      setSuccess(true)
      setTimeout(() => {
        router.push("/dashboard/jobs")
      }, 2000)
    } catch (error) {
      console.error("Error creating job:", error)
      setError("Failed to create job. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  if (success) {
    return (
      <div className="p-6 max-w-4xl mx-auto">
        <Card>
          <CardContent className="p-12 text-center">
            <CheckCircle className="h-16 w-16 text-green-600 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Job Created Successfully!</h2>
            <p className="text-gray-600 mb-4">Your job posting has been created and is now active.</p>
            <Button onClick={() => router.push("/dashboard/jobs")}>View All Jobs</Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="flex items-center gap-3 mb-6">
        <Briefcase className="h-8 w-8 text-blue-600" />
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Create New Job</h1>
          <p className="text-gray-600">Post a new job opening and start finding candidates</p>
        </div>
      </div>

      {error && (
        <Alert className="mb-6" variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Job Details</CardTitle>
          <CardDescription>Fill in the information about the position you're hiring for</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <Label htmlFor="title">Job Title *</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="e.g. Senior React Developer"
                  required
                />
              </div>

              <div className="md:col-span-2">
                <Label htmlFor="description">Job Description *</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Describe the role, responsibilities, and what you're looking for..."
                  rows={4}
                  required
                />
              </div>

              <div>
                <Label htmlFor="location">Location</Label>
                <Input
                  id="location"
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  placeholder="e.g. San Francisco, CA"
                />
              </div>

              <div>
                <Label htmlFor="job_type">Job Type *</Label>
                <Select
                  value={formData.job_type}
                  onValueChange={(value) => setFormData({ ...formData, job_type: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select job type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="full_time">Full Time</SelectItem>
                    <SelectItem value="part_time">Part Time</SelectItem>
                    <SelectItem value="contract">Contract</SelectItem>
                    <SelectItem value="internship">Internship</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="experience_required">Years of Experience</Label>
                <Input
                  id="experience_required"
                  type="number"
                  value={formData.experience_required}
                  onChange={(e) => setFormData({ ...formData, experience_required: e.target.value })}
                  placeholder="e.g. 3"
                  min="0"
                />
              </div>

              <div>
                <Label>Remote Work</Label>
                <Select
                  value={formData.remote_allowed ? "yes" : "no"}
                  onValueChange={(value) => setFormData({ ...formData, remote_allowed: value === "yes" })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Remote allowed?" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="yes">Remote Allowed</SelectItem>
                    <SelectItem value="no">On-site Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="salary_min">Minimum Salary ($)</Label>
                <Input
                  id="salary_min"
                  type="number"
                  value={formData.salary_range_min}
                  onChange={(e) => setFormData({ ...formData, salary_range_min: e.target.value })}
                  placeholder="e.g. 80000"
                />
              </div>
              <div>
                <Label htmlFor="salary_max">Maximum Salary ($)</Label>
                <Input
                  id="salary_max"
                  type="number"
                  value={formData.salary_range_max}
                  onChange={(e) => setFormData({ ...formData, salary_range_max: e.target.value })}
                  placeholder="e.g. 120000"
                />
              </div>
            </div>

            <div>
              <Label>Required Skills</Label>
              <div className="flex gap-2 mb-2">
                <Input
                  value={newSkill}
                  onChange={(e) => setNewSkill(e.target.value)}
                  placeholder="Add a skill..."
                  onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), addSkill())}
                />
                <Button type="button" onClick={addSkill} variant="outline">
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {skills.map((skill) => (
                  <Badge key={skill} variant="secondary" className="flex items-center gap-1">
                    {skill}
                    <button type="button" onClick={() => removeSkill(skill)} className="ml-1 hover:text-red-600">
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            </div>

            <div className="flex gap-4">
              <Button type="submit" disabled={loading} className="flex-1">
                {loading ? "Creating Job..." : "Create Job"}
              </Button>
              <Button type="button" variant="outline" onClick={() => router.back()}>
                Cancel
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
