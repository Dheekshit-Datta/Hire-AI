import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import DashboardContent from "@/components/dashboard/dashboard-content"

export default async function DashboardPage() {
  // Check if we're in demo mode (no Supabase credentials)
  if (!process.env.NEXT_PUBLIC_SUPABASE_URL || !process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY) {
    const mockUser = {
      id: "demo-user",
      email: "demo@hireai.com",
      full_name: "Demo User",
      company_name: "Demo Company",
      role: "recruiter",
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }

    const mockStats = {
      totalCandidates: 12,
      activeJobs: 3,
      recentSearches: [],
    }

    return <DashboardContent user={mockUser} stats={mockStats} />
  }

  try {
    const supabase = await createClient()

    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    // If no user and auth error, redirect to login
    if (authError || !user) {
      redirect("/auth/login")
    }

    // Create user profile with fallback data
    let profile = {
      id: user.id,
      email: user.email!,
      full_name: user.user_metadata?.full_name || user.email?.split("@")[0] || "User",
      company_name: user.user_metadata?.company_name || "Company",
      role: "recruiter" as const,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }

    // Try to fetch existing profile from database
    try {
      const { data: existingProfile, error: profileError } = await supabase
        .from("users")
        .select("*")
        .eq("id", user.id)
        .single()

      if (!profileError && existingProfile) {
        profile = existingProfile
      } else {
        // Try to create profile if it doesn't exist
        try {
          const { data: newProfile, error: createError } = await supabase
            .from("users")
            .insert({
              id: user.id,
              email: user.email!,
              full_name: profile.full_name,
              company_name: profile.company_name,
              role: "recruiter",
            })
            .select()
            .single()

          if (!createError && newProfile) {
            profile = newProfile
          }
        } catch (createProfileError) {
          console.warn("Could not create user profile, using fallback data")
        }
      }
    } catch (profileFetchError) {
      console.warn("Could not fetch user profile, using fallback data")
    }

    // Initialize stats with default values
    const stats = {
      totalCandidates: 0,
      activeJobs: 0,
      recentSearches: [],
    }

    // Try to fetch real stats from database
    try {
      const [candidatesResult, jobsResult, searchesResult] = await Promise.allSettled([
        supabase.from("candidates").select("id"),
        supabase.from("job_postings").select("id"),
        supabase.from("search_queries").select("*").order("created_at", { ascending: false }).limit(5),
      ])

      // Handle candidates count
      if (candidatesResult.status === "fulfilled" && candidatesResult.value.data) {
        stats.totalCandidates = candidatesResult.value.data.length
      }

      // Handle jobs count
      if (jobsResult.status === "fulfilled" && jobsResult.value.data) {
        stats.activeJobs = jobsResult.value.data.length
      }

      // Handle recent searches
      if (searchesResult.status === "fulfilled" && searchesResult.value.data) {
        stats.recentSearches = searchesResult.value.data
      }
    } catch (statsError) {
      console.warn("Could not fetch dashboard stats, using default values")
    }

    return <DashboardContent user={profile} stats={stats} />
  } catch (error) {
    // If there's any other error, check if it's a redirect
    if (
      error &&
      typeof error === "object" &&
      "digest" in error &&
      typeof error.digest === "string" &&
      error.digest.includes("NEXT_REDIRECT")
    ) {
      // This is a Next.js redirect, re-throw it
      throw error
    }

    console.warn("Dashboard initialization failed, falling back to demo mode")

    // Fallback to demo mode
    const mockUser = {
      id: "demo-user",
      email: "demo@hireai.com",
      full_name: "Demo User",
      company_name: "Demo Company",
      role: "recruiter" as const,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }

    const mockStats = {
      totalCandidates: 12,
      activeJobs: 3,
      recentSearches: [],
    }

    return <DashboardContent user={mockUser} stats={mockStats} />
  }
}
