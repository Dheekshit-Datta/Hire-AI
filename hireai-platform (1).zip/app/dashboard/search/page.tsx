"use client"

import { Suspense } from "react"
import SearchInterface from "@/components/dashboard/search-interface"
import { Card, CardContent } from "@/components/ui/card"
import { Brain } from "lucide-react"

export default function SearchPage() {
  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-3">
        <Brain className="h-8 w-8 text-blue-600" />
        <div>
          <h1 className="text-2xl font-bold text-gray-900">AI-Powered Candidate Search</h1>
          <p className="text-gray-600">Find the perfect candidates using natural language queries</p>
        </div>
      </div>

      <Suspense
        fallback={
          <Card>
            <CardContent className="p-12 text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
              <p className="text-gray-600">Loading AI search interface...</p>
            </CardContent>
          </Card>
        }
      >
        <SearchInterface />
      </Suspense>
    </div>
  )
}
