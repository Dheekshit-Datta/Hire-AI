"use client"

import { Suspense } from "react"
import CandidateList from "@/components/dashboard/candidate-list"
import { Card, CardContent } from "@/components/ui/card"
import { Users } from "lucide-react"

export default function CandidatesPage() {
  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-3">
        <Users className="h-8 w-8 text-blue-600" />
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Candidate Database</h1>
          <p className="text-gray-600">Manage and search through your candidate pool</p>
        </div>
      </div>

      <Suspense
        fallback={
          <Card>
            <CardContent className="p-12 text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
              <p className="text-gray-600">Loading candidates...</p>
            </CardContent>
          </Card>
        }
      >
        <CandidateList />
      </Suspense>
    </div>
  )
}
