export interface User {
  id: string
  email: string
  full_name: string
  role: "recruiter" | "admin"
  company_name?: string
  created_at: string
  updated_at: string
}

export interface Candidate {
  id: string
  email: string
  full_name: string
  phone?: string
  location?: string
  country?: string
  city?: string
  resume_url?: string
  resume_text?: string
  skills: string[]
  experience_years: number
  current_position?: string
  current_company?: string
  education: any[]
  certifications: any[]
  languages: string[]
  availability_status: "available" | "not_available" | "interviewing"
  salary_expectation?: number
  created_at: string
  updated_at: string
}

export interface JobPosting {
  id: string
  recruiter_id: string
  title: string
  description: string
  requirements: string[]
  skills_required: string[]
  location?: string
  country?: string
  city?: string
  salary_range_min?: number
  salary_range_max?: number
  experience_required: number
  job_type: "full_time" | "part_time" | "contract" | "internship"
  remote_allowed: boolean
  status: "active" | "paused" | "closed"
  created_at: string
  updated_at: string
}

export interface CandidateScore {
  id: string
  candidate_id: string
  job_posting_id: string
  overall_score: number
  skill_match_score: number
  experience_score: number
  location_score: number
  ai_reasoning?: string
  created_at: string
  candidate?: Candidate
}

export interface SearchQuery {
  id: string
  recruiter_id: string
  query_text: string
  parsed_criteria: any
  results_count: number
  execution_time_ms: number
  created_at: string
}

export interface BackgroundCheck {
  id: string
  candidate_id: string
  check_type: string
  status: "pending" | "completed" | "failed"
  results: any
  ai_summary?: string
  confidence_score: number
  created_at: string
}

export interface InterviewSession {
  id: string
  candidate_id: string
  job_posting_id: string
  session_type: "pre_screening" | "technical" | "behavioral"
  questions: any[]
  answers: any[]
  ai_analysis: any
  cheating_detected: boolean
  cheating_indicators: any[]
  overall_rating: number
  status: "scheduled" | "in_progress" | "completed" | "cancelled"
  created_at: string
  completed_at?: string
}

export interface AIDecisionLog {
  id: string
  action_type: string
  entity_type: string
  entity_id: string
  input_data: any
  ai_response: any
  confidence_score: number
  model_used?: string
  processing_time_ms: number
  created_at: string
}

export interface ParsedSearchCriteria {
  skills?: string[]
  location?: string
  experience_years?: number
  job_type?: string
  salary_range?: {
    min?: number
    max?: number
  }
  remote_allowed?: boolean
}
