import { generateText, generateObject } from "ai"
import { openai } from "@ai-sdk/openai"
import { z } from "zod"
import type { ParsedSearchCriteria } from "@/lib/types"

const searchCriteriaSchema = z.object({
  skills: z.array(z.string()).optional(),
  location: z.string().optional(),
  experience_years: z.number().optional(),
  job_type: z.enum(["full_time", "part_time", "contract", "internship"]).optional(),
  salary_range: z
    .object({
      min: z.number().optional(),
      max: z.number().optional(),
    })
    .optional(),
  remote_allowed: z.boolean().optional(),
})

export async function parseSearchQuery(query: string): Promise<ParsedSearchCriteria> {
  const { object } = await generateObject({
    model: openai("gpt-4o"),
    schema: searchCriteriaSchema,
    prompt: `Parse this recruitment search query into structured criteria: "${query}"
    
    Extract:
    - Skills mentioned (programming languages, frameworks, tools)
    - Location preferences (countries, cities, regions)
    - Experience requirements (years)
    - Job type preferences
    - Salary expectations
    - Remote work preferences
    
    Be flexible with synonyms and variations.`,
  })

  return object
}

export async function scoreCandidate(
  candidate: any,
  jobRequirements: any,
  searchCriteria: ParsedSearchCriteria,
): Promise<{
  overall_score: number
  skill_match_score: number
  experience_score: number
  location_score: number
  reasoning: string
}> {
  const { text } = await generateText({
    model: openai("gpt-4o"),
    prompt: `Score this candidate for the given job requirements and search criteria.

Candidate:
- Skills: ${JSON.stringify(candidate.skills)}
- Experience: ${candidate.experience_years} years
- Location: ${candidate.location}
- Current Position: ${candidate.current_position}
- Current Company: ${candidate.current_company}

Job Requirements:
${JSON.stringify(jobRequirements)}

Search Criteria:
${JSON.stringify(searchCriteria)}

Provide scores (0-100) for:
1. Skill Match Score
2. Experience Score  
3. Location Score
4. Overall Score (weighted average)

Format your response as JSON:
{
  "skill_match_score": number,
  "experience_score": number,
  "location_score": number,
  "overall_score": number,
  "reasoning": "detailed explanation of scoring"
}`,
  })

  try {
    return JSON.parse(text)
  } catch {
    return {
      overall_score: 0,
      skill_match_score: 0,
      experience_score: 0,
      location_score: 0,
      reasoning: "Failed to parse AI response",
    }
  }
}

export async function extractSkillsFromResume(resumeText: string): Promise<string[]> {
  const { text } = await generateText({
    model: openai("gpt-4o"),
    prompt: `Extract all technical skills, programming languages, frameworks, tools, and technologies from this resume text:

${resumeText}

Return only a JSON array of skills, no other text:
["skill1", "skill2", "skill3"]`,
  })

  try {
    return JSON.parse(text)
  } catch {
    return []
  }
}

export async function generateBackgroundCheck(candidate: any): Promise<{
  summary: string
  confidence_score: number
  findings: any[]
}> {
  const { text } = await generateText({
    model: openai("gpt-4o"),
    prompt: `Generate a simulated background check summary for this candidate:

Name: ${candidate.full_name}
Email: ${candidate.email}
Current Position: ${candidate.current_position}
Current Company: ${candidate.current_company}
Experience: ${candidate.experience_years} years

Provide a realistic background check summary including:
- Employment verification
- Education verification
- Professional references
- Any potential red flags or positive indicators

Format as JSON:
{
  "summary": "overall summary",
  "confidence_score": number (0-100),
  "findings": [
    {"type": "employment", "status": "verified", "details": "..."},
    {"type": "education", "status": "verified", "details": "..."}
  ]
}`,
  })

  try {
    return JSON.parse(text)
  } catch {
    return {
      summary: "Background check failed to process",
      confidence_score: 0,
      findings: [],
    }
  }
}

export async function generateInterviewQuestions(
  jobTitle: string,
  skills: string[],
  sessionType: string,
): Promise<any[]> {
  const { text } = await generateText({
    model: openai("gpt-4o"),
    prompt: `Generate ${sessionType} interview questions for a ${jobTitle} position requiring these skills: ${skills.join(", ")}

Generate 5-7 relevant questions. Format as JSON array:
[
  {
    "question": "question text",
    "type": "technical|behavioral|situational",
    "difficulty": "easy|medium|hard",
    "expected_topics": ["topic1", "topic2"]
  }
]`,
  })

  try {
    return JSON.parse(text)
  } catch {
    return []
  }
}

export async function analyzeInterviewResponse(
  question: string,
  answer: string,
  expectedTopics: string[],
): Promise<{
  score: number
  feedback: string
  cheating_indicators: string[]
}> {
  const { text } = await generateText({
    model: openai("gpt-4o"),
    prompt: `Analyze this interview response for quality and potential cheating indicators:

Question: ${question}
Answer: ${answer}
Expected Topics: ${expectedTopics.join(", ")}

Evaluate:
1. Technical accuracy
2. Depth of understanding
3. Communication clarity
4. Potential cheating indicators (copy-paste, unrealistic perfection, etc.)

Format as JSON:
{
  "score": number (0-100),
  "feedback": "detailed feedback",
  "cheating_indicators": ["indicator1", "indicator2"]
}`,
  })

  try {
    return JSON.parse(text)
  } catch {
    return {
      score: 0,
      feedback: "Failed to analyze response",
      cheating_indicators: [],
    }
  }
}
