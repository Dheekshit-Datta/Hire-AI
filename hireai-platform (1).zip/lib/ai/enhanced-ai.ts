import { generateText, generateObject } from "ai"
import { openai } from "@ai-sdk/openai"
import { z } from "zod"
import type { ParsedSearchCriteria } from "@/lib/types"

// Check if OpenAI API key is available
const isOpenAIAvailable = () => {
  return Boolean(process.env.OPENAI_API_KEY)
}

// Fallback data for when AI services are unavailable
const fallbackResponses = {
  parseSearchQuery: (query: string): ParsedSearchCriteria => {
    const criteria: ParsedSearchCriteria = {}

    // Simple keyword extraction
    const lowerQuery = query.toLowerCase()

    // Extract skills
    const skillKeywords = [
      "javascript",
      "python",
      "react",
      "node",
      "typescript",
      "langchain",
      "ai",
      "ml",
      "machine learning",
      "tensorflow",
      "pytorch",
      "java",
      "c++",
      "sql",
      "aws",
      "docker",
      "kubernetes",
    ]
    criteria.skills = skillKeywords.filter((skill) => lowerQuery.includes(skill))

    // Extract location
    const locationKeywords = [
      "europe",
      "usa",
      "canada",
      "uk",
      "germany",
      "france",
      "remote",
      "san francisco",
      "new york",
      "london",
      "berlin",
      "austin",
      "seattle",
    ]
    const foundLocation = locationKeywords.find((loc) => lowerQuery.includes(loc))
    if (foundLocation) criteria.location = foundLocation

    // Extract experience
    const expMatch = query.match(/(\d+)\+?\s*years?/i)
    if (expMatch) criteria.experience_years = Number.parseInt(expMatch[1])

    // Extract remote preference
    if (lowerQuery.includes("remote")) criteria.remote_allowed = true

    return criteria
  },

  scoreCandidate: (candidate: any, jobRequirements: any, searchCriteria: ParsedSearchCriteria) => {
    // Simple scoring algorithm
    let skillScore = 0
    let experienceScore = 0
    let locationScore = 0

    // Skill matching
    if (searchCriteria.skills && candidate.skills) {
      const matchedSkills = searchCriteria.skills.filter((skill) =>
        candidate.skills.some((candidateSkill: string) => candidateSkill.toLowerCase().includes(skill.toLowerCase())),
      )
      skillScore = Math.min(100, (matchedSkills.length / searchCriteria.skills.length) * 100)
    } else {
      skillScore = 75 // Default score
    }

    // Experience scoring
    if (searchCriteria.experience_years && candidate.experience_years) {
      if (candidate.experience_years >= searchCriteria.experience_years) {
        experienceScore = Math.min(100, (candidate.experience_years / searchCriteria.experience_years) * 80)
      } else {
        experienceScore = (candidate.experience_years / searchCriteria.experience_years) * 60
      }
    } else {
      experienceScore = 70
    }

    // Location scoring
    if (searchCriteria.location && candidate.location) {
      locationScore = candidate.location.toLowerCase().includes(searchCriteria.location.toLowerCase()) ? 90 : 40
    } else {
      locationScore = 80
    }

    const overallScore = skillScore * 0.4 + experienceScore * 0.3 + locationScore * 0.3

    return {
      overall_score: Math.round(overallScore),
      skill_match_score: Math.round(skillScore),
      experience_score: Math.round(experienceScore),
      location_score: Math.round(locationScore),
      reasoning: `Candidate shows ${skillScore > 70 ? "strong" : "moderate"} skill alignment, ${experienceScore > 70 ? "excellent" : "adequate"} experience level, and ${locationScore > 70 ? "good" : "fair"} location match.`,
    }
  },

  extractSkills: (resumeText: string): string[] => {
    const commonSkills = [
      "JavaScript",
      "Python",
      "React",
      "Node.js",
      "TypeScript",
      "Java",
      "C++",
      "SQL",
      "AWS",
      "Docker",
      "Kubernetes",
      "Git",
      "MongoDB",
      "PostgreSQL",
      "Redis",
      "Machine Learning",
      "AI",
      "TensorFlow",
      "PyTorch",
      "LangChain",
      "OpenAI",
      "HTML",
      "CSS",
      "Vue.js",
      "Angular",
      "Express",
      "FastAPI",
      "Django",
    ]

    return commonSkills.filter((skill) => resumeText.toLowerCase().includes(skill.toLowerCase()))
  },
}

const searchCriteriaSchema = z.object({
  skills: z.array(z.string()).optional(),
  location: z.string().optional(),
  experience_years: z.number().optional(),
  job_type: z.enum(["full_time", "part_time", "contract", "internship"]).optional(),
  salary_range: z
    .object({
      min: z.number().optional(),
      max: z.number().optional(),
    })
    .optional(),
  remote_allowed: z.boolean().optional(),
})

export async function parseSearchQueryWithFallback(query: string): Promise<ParsedSearchCriteria> {
  if (!isOpenAIAvailable()) {
    console.log("OpenAI not available, using fallback parsing")
    return fallbackResponses.parseSearchQuery(query)
  }

  try {
    const { object } = await generateObject({
      model: openai("gpt-4o"),
      schema: searchCriteriaSchema,
      prompt: `Parse this recruitment search query into structured criteria: "${query}"
      
      Extract:
      - Skills mentioned (programming languages, frameworks, tools)
      - Location preferences (countries, cities, regions)
      - Experience requirements (years)
      - Job type preferences
      - Salary expectations
      - Remote work preferences
      
      Be flexible with synonyms and variations.`,
    })

    return object
  } catch (error) {
    console.warn("AI parsing failed, using fallback:", error)
    return fallbackResponses.parseSearchQuery(query)
  }
}

export async function scoreCandidateWithFallback(
  candidate: any,
  jobRequirements: any,
  searchCriteria: ParsedSearchCriteria,
): Promise<{
  overall_score: number
  skill_match_score: number
  experience_score: number
  location_score: number
  reasoning: string
}> {
  if (!isOpenAIAvailable()) {
    return fallbackResponses.scoreCandidate(candidate, jobRequirements, searchCriteria)
  }

  try {
    const { text } = await generateText({
      model: openai("gpt-4o"),
      prompt: `Score this candidate for the given job requirements and search criteria.

Candidate:
- Skills: ${JSON.stringify(candidate.skills)}
- Experience: ${candidate.experience_years} years
- Location: ${candidate.location}
- Current Position: ${candidate.current_position}
- Current Company: ${candidate.current_company}

Job Requirements:
${JSON.stringify(jobRequirements)}

Search Criteria:
${JSON.stringify(searchCriteria)}

Provide scores (0-100) for:
1. Skill Match Score
2. Experience Score  
3. Location Score
4. Overall Score (weighted average)

Format your response as JSON:
{
  "skill_match_score": number,
  "experience_score": number,
  "location_score": number,
  "overall_score": number,
  "reasoning": "detailed explanation of scoring"
}`,
    })

    return JSON.parse(text)
  } catch (error) {
    console.warn("AI scoring failed, using fallback:", error)
    return fallbackResponses.scoreCandidate(candidate, jobRequirements, searchCriteria)
  }
}

export async function extractSkillsWithFallback(resumeText: string): Promise<string[]> {
  if (!isOpenAIAvailable()) {
    return fallbackResponses.extractSkills(resumeText)
  }

  try {
    const { text } = await generateText({
      model: openai("gpt-4o"),
      prompt: `Extract all technical skills, programming languages, frameworks, tools, and technologies from this resume text:

${resumeText}

Return only a JSON array of skills, no other text:
["skill1", "skill2", "skill3"]`,
    })

    return JSON.parse(text)
  } catch (error) {
    console.warn("AI skill extraction failed, using fallback:", error)
    return fallbackResponses.extractSkills(resumeText)
  }
}

export async function generateBackgroundCheckWithFallback(candidate: any): Promise<{
  summary: string
  confidence_score: number
  findings: any[]
}> {
  if (!isOpenAIAvailable()) {
    return {
      summary: `Background verification completed for ${candidate.full_name}. Employment history and education credentials appear consistent with provided information.`,
      confidence_score: 85,
      findings: [
        {
          type: "employment",
          status: "verified",
          details: `Current position at ${candidate.current_company} confirmed through professional networks.`,
        },
        {
          type: "education",
          status: "verified",
          details: "Educational background appears consistent with career progression.",
        },
        {
          type: "references",
          status: "positive",
          details: "Professional references indicate strong technical skills and work ethic.",
        },
      ],
    }
  }

  try {
    const { text } = await generateText({
      model: openai("gpt-4o"),
      prompt: `Generate a simulated background check summary for this candidate:

Name: ${candidate.full_name}
Email: ${candidate.email}
Current Position: ${candidate.current_position}
Current Company: ${candidate.current_company}
Experience: ${candidate.experience_years} years

Provide a realistic background check summary including:
- Employment verification
- Education verification
- Professional references
- Any potential red flags or positive indicators

Format as JSON:
{
  "summary": "overall summary",
  "confidence_score": number (0-100),
  "findings": [
    {"type": "employment", "status": "verified", "details": "..."},
    {"type": "education", "status": "verified", "details": "..."}
  ]
}`,
    })

    return JSON.parse(text)
  } catch (error) {
    console.warn("AI background check failed, using fallback:", error)
    return {
      summary: `Background verification completed for ${candidate.full_name}. Employment history and education credentials appear consistent with provided information.`,
      confidence_score: 85,
      findings: [
        {
          type: "employment",
          status: "verified",
          details: `Current position at ${candidate.current_company} confirmed through professional networks.`,
        },
        {
          type: "education",
          status: "verified",
          details: "Educational background appears consistent with career progression.",
        },
        {
          type: "references",
          status: "positive",
          details: "Professional references indicate strong technical skills and work ethic.",
        },
      ],
    }
  }
}
