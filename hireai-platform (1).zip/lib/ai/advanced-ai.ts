import { generateText, generateObject } from "ai"
import { openai } from "@ai-sdk/openai"
import { z } from "zod"
import type { Candidate, ParsedSearchCriteria } from "@/lib/types"

// Enhanced resume parsing schema
const resumeParsingSchema = z.object({
  skills: z.array(z.string()),
  experience_years: z.number(),
  education: z.array(
    z.object({
      degree: z.string(),
      school: z.string(),
      year: z.number().optional(),
      field: z.string().optional(),
    }),
  ),
  certifications: z.array(
    z.object({
      name: z.string(),
      issuer: z.string(),
      year: z.number().optional(),
    }),
  ),
  languages: z.array(z.string()),
  current_position: z.string().optional(),
  current_company: z.string().optional(),
  previous_positions: z.array(
    z.object({
      title: z.string(),
      company: z.string(),
      duration: z.string(),
      responsibilities: z.array(z.string()),
    }),
  ),
  achievements: z.array(z.string()),
  projects: z.array(
    z.object({
      name: z.string(),
      description: z.string(),
      technologies: z.array(z.string()),
    }),
  ),
})

// Advanced candidate scoring schema
const candidateScoringSchema = z.object({
  overall_score: z.number().min(0).max(100),
  skill_match_score: z.number().min(0).max(100),
  experience_score: z.number().min(0).max(100),
  location_score: z.number().min(0).max(100),
  education_score: z.number().min(0).max(100),
  cultural_fit_score: z.number().min(0).max(100),
  growth_potential_score: z.number().min(0).max(100),
  reasoning: z.string(),
  strengths: z.array(z.string()),
  weaknesses: z.array(z.string()),
  recommendations: z.array(z.string()),
})

// Background check schema
const backgroundCheckSchema = z.object({
  overall_risk_level: z.enum(["low", "medium", "high"]),
  confidence_score: z.number().min(0).max(100),
  employment_verification: z.object({
    status: z.enum(["verified", "unverified", "discrepancy"]),
    details: z.string(),
    risk_factors: z.array(z.string()),
  }),
  education_verification: z.object({
    status: z.enum(["verified", "unverified", "discrepancy"]),
    details: z.string(),
    risk_factors: z.array(z.string()),
  }),
  reference_check: z.object({
    status: z.enum(["positive", "neutral", "negative"]),
    details: z.string(),
    feedback_summary: z.string(),
  }),
  red_flags: z.array(z.string()),
  positive_indicators: z.array(z.string()),
  summary: z.string(),
  recommendation: z.enum(["proceed", "proceed_with_caution", "do_not_proceed"]),
})

// Interview questions schema
const interviewQuestionsSchema = z.object({
  questions: z.array(
    z.object({
      id: z.string(),
      question: z.string(),
      type: z.enum(["technical", "behavioral", "situational", "problem_solving"]),
      difficulty: z.enum(["easy", "medium", "hard"]),
      expected_topics: z.array(z.string()),
      evaluation_criteria: z.array(z.string()),
      time_limit_minutes: z.number().optional(),
    }),
  ),
  session_overview: z.string(),
  total_estimated_time: z.number(),
})

// Interview analysis schema
const interviewAnalysisSchema = z.object({
  overall_score: z.number().min(0).max(100),
  technical_competency: z.number().min(0).max(100),
  communication_skills: z.number().min(0).max(100),
  problem_solving: z.number().min(0).max(100),
  cultural_fit: z.number().min(0).max(100),
  cheating_probability: z.number().min(0).max(100),
  cheating_indicators: z.array(z.string()),
  strengths: z.array(z.string()),
  areas_for_improvement: z.array(z.string()),
  detailed_feedback: z.string(),
  recommendation: z.enum(["strong_hire", "hire", "maybe", "no_hire"]),
  next_steps: z.array(z.string()),
})

export async function parseResumeWithAI(resumeText: string): Promise<any> {
  const { object } = await generateObject({
    model: openai("gpt-4o"),
    schema: resumeParsingSchema,
    prompt: `Parse this resume and extract all relevant information in a structured format:

${resumeText}

Extract:
- All technical skills, programming languages, frameworks, tools
- Years of experience (calculate from work history)
- Education details with degrees, schools, years
- Certifications with issuers and years
- Languages spoken
- Current and previous positions with responsibilities
- Notable achievements and projects
- Technologies used in projects

Be thorough and accurate. If information is unclear, make reasonable inferences based on context.`,
  })

  return object
}

export async function advancedCandidateScoring(
  candidate: Candidate,
  jobRequirements: any,
  searchCriteria: ParsedSearchCriteria,
): Promise<any> {
  const { object } = await generateObject({
    model: openai("gpt-4o"),
    schema: candidateScoringSchema,
    prompt: `Perform a comprehensive evaluation of this candidate for the given job requirements.

CANDIDATE PROFILE:
Name: ${candidate.full_name}
Current Position: ${candidate.current_position}
Company: ${candidate.current_company}
Experience: ${candidate.experience_years} years
Location: ${candidate.location}
Skills: ${JSON.stringify(candidate.skills)}
Education: ${JSON.stringify(candidate.education)}
Certifications: ${JSON.stringify(candidate.certifications)}

JOB REQUIREMENTS:
${JSON.stringify(jobRequirements)}

SEARCH CRITERIA:
${JSON.stringify(searchCriteria)}

Evaluate the candidate on these dimensions (0-100 scale):
1. Skill Match Score - How well do their skills align with requirements?
2. Experience Score - Is their experience level and type relevant?
3. Location Score - Geographic fit and remote work compatibility
4. Education Score - Educational background relevance
5. Cultural Fit Score - Based on company background and career progression
6. Growth Potential Score - Ability to grow and adapt

Provide detailed reasoning, strengths, weaknesses, and specific recommendations.
Be objective and thorough in your analysis.`,
  })

  return object
}

export async function generateComprehensiveBackgroundCheck(candidate: Candidate): Promise<any> {
  const { object } = await generateObject({
    model: openai("gpt-4o"),
    schema: backgroundCheckSchema,
    prompt: `Generate a comprehensive background check analysis for this candidate:

CANDIDATE:
Name: ${candidate.full_name}
Email: ${candidate.email}
Current Position: ${candidate.current_position}
Current Company: ${candidate.current_company}
Experience: ${candidate.experience_years} years
Education: ${JSON.stringify(candidate.education)}
Location: ${candidate.location}

Simulate a thorough background check including:

1. EMPLOYMENT VERIFICATION
- Verify current and previous employment
- Check for employment gaps or inconsistencies
- Assess career progression and stability

2. EDUCATION VERIFICATION
- Verify degrees and institutions
- Check for any discrepancies in educational claims
- Assess relevance of education to role

3. REFERENCE CHECK
- Simulate feedback from previous supervisors/colleagues
- Assess professional reputation and work quality
- Identify any performance concerns

4. RISK ASSESSMENT
- Identify any red flags or concerns
- Highlight positive indicators
- Assess overall risk level

Provide realistic, detailed analysis with specific findings and recommendations.
Base your assessment on typical patterns and realistic scenarios.`,
  })

  return object
}

export async function generateAdaptiveInterviewQuestions(
  jobTitle: string,
  requiredSkills: string[],
  candidateProfile: Candidate,
  sessionType: "pre_screening" | "technical" | "behavioral",
): Promise<any> {
  const { object } = await generateObject({
    model: openai("gpt-4o"),
    schema: interviewQuestionsSchema,
    prompt: `Generate adaptive interview questions for a ${sessionType} session.

JOB DETAILS:
Position: ${jobTitle}
Required Skills: ${requiredSkills.join(", ")}

CANDIDATE PROFILE:
Name: ${candidateProfile.full_name}
Current Role: ${candidateProfile.current_position}
Experience: ${candidateProfile.experience_years} years
Skills: ${candidateProfile.skills.join(", ")}
Background: ${candidateProfile.current_company}

Generate 5-7 questions that are:
1. Tailored to the candidate's background and experience level
2. Relevant to the job requirements
3. Appropriate for the session type (${sessionType})
4. Progressive in difficulty
5. Designed to reveal both technical competency and soft skills

For each question, provide:
- Clear evaluation criteria
- Expected topics in responses
- Difficulty level
- Estimated time needed

Include a session overview and total estimated time.`,
  })

  return object
}

export async function analyzeInterviewResponseAdvanced(
  question: string,
  candidateAnswer: string,
  expectedTopics: string[],
  evaluationCriteria: string[],
  candidateProfile: Candidate,
): Promise<any> {
  const { object } = await generateObject({
    model: openai("gpt-4o"),
    schema: interviewAnalysisSchema,
    prompt: `Analyze this interview response comprehensively:

QUESTION: ${question}

CANDIDATE ANSWER: ${candidateAnswer}

EXPECTED TOPICS: ${expectedTopics.join(", ")}

EVALUATION CRITERIA: ${evaluationCriteria.join(", ")}

CANDIDATE BACKGROUND:
Experience: ${candidateProfile.experience_years} years
Skills: ${candidateProfile.skills.join(", ")}
Current Role: ${candidateProfile.current_position}

Evaluate the response on:
1. Technical Competency (0-100)
2. Communication Skills (0-100)
3. Problem Solving Approach (0-100)
4. Cultural Fit Indicators (0-100)
5. Overall Score (0-100)

CHEATING DETECTION:
Analyze for potential cheating indicators:
- Overly perfect or scripted responses
- Inconsistency with claimed experience level
- Copy-paste patterns or unnatural language
- Responses that don't match the question
- Unrealistic depth for the time given

Provide:
- Detailed feedback on the response quality
- Specific strengths and improvement areas
- Hiring recommendation
- Suggested next steps
- Cheating probability assessment`,
  })

  return object
}

export async function intelligentCandidateRanking(
  candidates: Candidate[],
  jobRequirements: any,
  searchCriteria: ParsedSearchCriteria,
  weights: {
    skills: number
    experience: number
    location: number
    education: number
    cultural_fit: number
  } = { skills: 0.3, experience: 0.25, location: 0.15, education: 0.15, cultural_fit: 0.15 },
): Promise<any[]> {
  const scoredCandidates = []

  for (const candidate of candidates) {
    try {
      const scoring = await advancedCandidateScoring(candidate, jobRequirements, searchCriteria)

      // Calculate weighted score
      const weightedScore =
        scoring.skill_match_score * weights.skills +
        scoring.experience_score * weights.experience +
        scoring.location_score * weights.location +
        scoring.education_score * weights.education +
        scoring.cultural_fit_score * weights.cultural_fit

      scoredCandidates.push({
        candidate,
        scoring,
        weighted_score: weightedScore,
        rank: 0, // Will be set after sorting
      })
    } catch (error) {
      console.error(`Failed to score candidate ${candidate.id}:`, error)
    }
  }

  // Sort by weighted score and assign ranks
  scoredCandidates.sort((a, b) => b.weighted_score - a.weighted_score)
  scoredCandidates.forEach((item, index) => {
    item.rank = index + 1
  })

  return scoredCandidates
}

export async function generateJobDescriptionInsights(jobDescription: string): Promise<any> {
  const { text } = await generateText({
    model: openai("gpt-4o"),
    prompt: `Analyze this job description and extract key insights:

${jobDescription}

Provide analysis on:
1. Required technical skills (extract and categorize)
2. Experience level requirements
3. Soft skills and cultural requirements
4. Location and remote work preferences
5. Compensation indicators
6. Company culture clues
7. Growth opportunities mentioned
8. Potential challenges or red flags

Format as JSON with structured insights that can be used for candidate matching.`,
  })

  try {
    return JSON.parse(text)
  } catch {
    return { error: "Failed to parse job description insights" }
  }
}

export async function predictCandidateSuccess(
  candidate: Candidate,
  jobRequirements: any,
  companyProfile: any,
): Promise<any> {
  const { text } = await generateText({
    model: openai("gpt-4o"),
    prompt: `Predict the likelihood of success for this candidate in the given role:

CANDIDATE:
${JSON.stringify(candidate)}

JOB REQUIREMENTS:
${JSON.stringify(jobRequirements)}

COMPANY PROFILE:
${JSON.stringify(companyProfile)}

Analyze and predict:
1. Success probability (0-100%)
2. Time to productivity
3. Retention likelihood
4. Performance potential
5. Cultural integration probability
6. Growth trajectory prediction

Consider factors like:
- Skill alignment and learning curve
- Career progression patterns
- Company culture fit
- Industry experience
- Geographic factors
- Compensation alignment

Provide detailed reasoning and confidence intervals.`,
  })

  try {
    return JSON.parse(text)
  } catch {
    return { error: "Failed to generate success prediction" }
  }
}
