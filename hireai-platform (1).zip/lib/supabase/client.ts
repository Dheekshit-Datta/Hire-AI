import { createBrowserClient } from "@supabase/ssr"

export function createClient() {
  try {
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
    const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

    if (!supabaseUrl || !supabaseAnonKey) {
      console.warn("Supabase environment variables not found, using demo mode")
      // Return a mock client for demo mode
      return {
        auth: {
          signInWithPassword: async ({ email, password }: { email: string; password: string }) => {
            if (email === "demo@hireai.com" && password === "demo123") {
              return {
                data: {
                  user: {
                    id: "demo-user-id",
                    email: "demo@hireai.com",
                    user_metadata: { full_name: "Demo User" },
                  },
                },
                error: null,
              }
            }
            return {
              data: { user: null },
              error: { message: "Invalid credentials" },
            }
          },
          signUp: async ({ email, password, options }: any) => {
            return {
              data: {
                user: {
                  id: "new-user-id",
                  email,
                  user_metadata: options?.data || {},
                },
              },
              error: null,
            }
          },
          signInWithOAuth: async ({ provider }: { provider: string }) => {
            return { error: null }
          },
          signOut: async () => {
            return { error: null }
          },
          getSession: async () => {
            return {
              data: { session: null },
              error: null,
            }
          },
          onAuthStateChange: () => {
            return {
              data: {
                subscription: {
                  unsubscribe: () => {},
                },
              },
            }
          },
          getUser: async () => {
            return {
              data: { user: null },
              error: null,
            }
          },
        },
        from: () => ({
          select: () => ({
            eq: () => ({
              single: async () => ({ data: null, error: null }),
            }),
          }),
          insert: () => ({
            select: () => ({
              single: async () => ({ data: null, error: null }),
            }),
          }),
          update: () => ({
            eq: () => ({
              select: () => ({
                single: async () => ({ data: null, error: null }),
              }),
            }),
          }),
          delete: () => ({
            eq: async () => ({ data: null, error: null }),
          }),
        }),
      } as any
    }

    return createBrowserClient(supabaseUrl, supabaseAnonKey)
  } catch (error) {
    console.warn("Failed to create Supabase client, using demo mode:", error)
    // Return the same mock client as above
    return {
      auth: {
        signInWithPassword: async ({ email, password }: { email: string; password: string }) => {
          if (email === "demo@hireai.com" && password === "demo123") {
            return {
              data: {
                user: {
                  id: "demo-user-id",
                  email: "demo@hireai.com",
                  user_metadata: { full_name: "Demo User" },
                },
              },
              error: null,
            }
          }
          return {
            data: { user: null },
            error: { message: "Invalid credentials" },
          }
        },
        signUp: async ({ email, password, options }: any) => {
          return {
            data: {
              user: {
                id: "new-user-id",
                email,
                user_metadata: options?.data || {},
              },
            },
            error: null,
          }
        },
        signInWithOAuth: async ({ provider }: { provider: string }) => {
          return { error: null }
        },
        signOut: async () => {
          return { error: null }
        },
        getSession: async () => {
          return {
            data: { session: null },
            error: null,
          }
        },
        onAuthStateChange: () => {
          return {
            data: {
              subscription: {
                unsubscribe: () => {},
              },
            },
          }
        },
        getUser: async () => {
          return {
            data: { user: null },
            error: null,
          }
        },
      },
      from: () => ({
        select: () => ({
          eq: () => ({
            single: async () => ({ data: null, error: null }),
          }),
        }),
        insert: () => ({
          select: () => ({
            single: async () => ({ data: null, error: null }),
          }),
        }),
        update: () => ({
          eq: () => ({
            select: () => ({
              single: async () => ({ data: null, error: null }),
            }),
          }),
        }),
        delete: () => ({
          eq: async () => ({ data: null, error: null }),
        }),
      }),
    } as any
  }
}
