/**
 * Utility functions to extract structured information from natural language search queries
 */

export function extractSkillsFromQuery(query: string): string[] {
  const commonSkills = [
    "javascript",
    "python",
    "react",
    "node",
    "typescript",
    "java",
    "c++",
    "sql",
    "aws",
    "docker",
    "kubernetes",
    "git",
    "mongodb",
    "postgresql",
    "redis",
    "machine learning",
    "ai",
    "tensorflow",
    "pytorch",
    "langchain",
    "openai",
    "angular",
    "vue",
    "svelte",
    "next.js",
    "graphql",
    "rest api",
    "django",
    "flask",
    "spring",
    "express",
    "ruby",
    "php",
    "golang",
    "rust",
    "swift",
    "kotlin",
    "mobile",
    "ios",
    "android",
    "react native",
    "flutter",
    "devops",
    "ci/cd",
    "jenkins",
    "github actions",
    "terraform",
    "ansible",
    "data science",
    "data engineering",
    "big data",
    "spark",
    "hadoop",
    "kafka",
    "product management",
    "agile",
    "scrum",
    "jira",
    "figma",
    "ui/ux",
    "design",
  ]

  return commonSkills.filter((skill) => query.toLowerCase().includes(skill.toLowerCase()))
}

export function extractLocationFromQuery(query: string): string | undefined {
  const locations = [
    "europe",
    "usa",
    "united states",
    "canada",
    "uk",
    "united kingdom",
    "germany",
    "france",
    "spain",
    "italy",
    "netherlands",
    "sweden",
    "australia",
    "india",
    "japan",
    "china",
    "brazil",
    "remote",
    "san francisco",
    "new york",
    "london",
    "berlin",
    "paris",
    "toronto",
    "singapore",
    "hong kong",
    "dubai",
    "tel aviv",
    "seattle",
    "boston",
    "chicago",
    "los angeles",
    "austin",
    "miami",
    "vancouver",
    "sydney",
    "melbourne",
    "bangalore",
    "mumbai",
    "tokyo",
    "seoul",
    "shanghai",
    "beijing",
    "amsterdam",
    "dublin",
    "zurich",
    "stockholm",
    "copenhagen",
  ]

  for (const location of locations) {
    if (query.toLowerCase().includes(location.toLowerCase())) {
      return location
    }
  }

  return undefined
}

export function extractExperienceFromQuery(query: string): string | undefined {
  // Look for patterns like "5+ years", "at least 3 years", "minimum 7 years"
  const patterns = [
    /(\d+)\+?\s*years?/i,
    /at least (\d+)\s*years?/i,
    /minimum (\d+)\s*years?/i,
    /(\d+)\s*years? of experience/i,
    /experience\D+(\d+)\s*years?/i,
  ]

  for (const pattern of patterns) {
    const match = query.match(pattern)
    if (match && match[1]) {
      return `${match[1]}+ years`
    }
  }

  // Look for experience level keywords
  const experienceLevels = {
    "entry level": "0-2 years",
    junior: "0-2 years",
    "mid level": "3-5 years",
    "mid-level": "3-5 years",
    senior: "6+ years",
    lead: "8+ years",
    principal: "10+ years",
    director: "10+ years",
    executive: "15+ years",
  }

  for (const [level, years] of Object.entries(experienceLevels)) {
    if (query.toLowerCase().includes(level)) {
      return years
    }
  }

  return undefined
}

export function extractCompanyFromQuery(query: string): string | undefined {
  const companies = [
    "google",
    "microsoft",
    "amazon",
    "apple",
    "facebook",
    "meta",
    "netflix",
    "twitter",
    "linkedin",
    "uber",
    "airbnb",
    "stripe",
    "shopify",
    "salesforce",
    "oracle",
    "ibm",
    "intel",
    "amd",
    "nvidia",
    "tesla",
    "spacex",
    "adobe",
    "dropbox",
    "slack",
    "zoom",
    "spotify",
    "paypal",
    "square",
    "twilio",
    "atlassian",
    "github",
    "gitlab",
    "bitbucket",
    "heroku",
    "digitalocean",
  ]

  // Look for "at [company]" or "from [company]" patterns
  const atPattern = /\b(?:at|from)\s+([A-Z][a-zA-Z0-9\s]+)(?:\b|$)/i
  const match = query.match(atPattern)
  if (match && match[1]) {
    return match[1].trim()
  }

  // Check for known company names
  for (const company of companies) {
    if (query.toLowerCase().includes(company.toLowerCase())) {
      return company
    }
  }

  return undefined
}

export function extractJobTitleFromQuery(query: string): string | undefined {
  const titles = [
    "software engineer",
    "frontend developer",
    "backend developer",
    "full stack developer",
    "data scientist",
    "data engineer",
    "machine learning engineer",
    "ai engineer",
    "devops engineer",
    "site reliability engineer",
    "product manager",
    "project manager",
    "ux designer",
    "ui designer",
    "graphic designer",
    "web designer",
    "mobile developer",
    "ios developer",
    "android developer",
    "qa engineer",
    "test engineer",
    "security engineer",
    "cloud engineer",
    "solutions architect",
    "technical architect",
    "engineering manager",
    "cto",
    "vp of engineering",
    "director of engineering",
    "tech lead",
    "team lead",
  ]

  for (const title of titles) {
    if (query.toLowerCase().includes(title.toLowerCase())) {
      return title
    }
  }

  return undefined
}

export function extractIndustryFromQuery(query: string): string | undefined {
  const industries = [
    "technology",
    "finance",
    "healthcare",
    "education",
    "manufacturing",
    "retail",
    "media",
    "entertainment",
    "consulting",
    "government",
    "non-profit",
    "automotive",
    "aerospace",
    "energy",
    "telecom",
    "pharmaceutical",
    "biotech",
    "insurance",
    "real estate",
    "hospitality",
  ]

  for (const industry of industries) {
    if (query.toLowerCase().includes(industry.toLowerCase())) {
      return industry
    }
  }

  return undefined
}
